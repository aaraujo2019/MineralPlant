﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmPrincipal
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmPrincipal))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.PlantaBeneficioToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MineralPlantToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DespacharMuestraLabToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CargarAnalisisQuimicosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CargarAnalisisQuimicosZandorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GravedadEspecificaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CargarGravedadEspecificaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CargarHumedadesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FundiciónToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PieDeBandaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExportFlujosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NovedadesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MinerasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MuestreoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImportarBasculaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportesToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MerrilCroweToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AlimentoMolinoB12ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReporteVertimientoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FlujosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IngresarDensidadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EspesadoresToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AgitadoresToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DensidadesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConfiguracionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MuestrasInstantaneasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImportarInstantaneasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GranulometríaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImportarSinExcelToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConsumoReactivosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConsumoDiarioToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AgregarReactivosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.LblUserName = New System.Windows.Forms.Label()
        Me.lbltipoflujo = New System.Windows.Forms.Label()
        Me.BalanceMetalurgicoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PlantaBeneficioToolStripMenuItem, Me.MinerasToolStripMenuItem, Me.ReportesToolStripMenuItem1, Me.FlujosToolStripMenuItem, Me.ConsumoReactivosToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(8, 2, 0, 2)
        Me.MenuStrip1.Size = New System.Drawing.Size(1370, 28)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'PlantaBeneficioToolStripMenuItem
        '
        Me.PlantaBeneficioToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MineralPlantToolStripMenuItem, Me.DespacharMuestraLabToolStripMenuItem, Me.CargarAnalisisQuimicosToolStripMenuItem, Me.CargarAnalisisQuimicosZandorToolStripMenuItem, Me.GravedadEspecificaToolStripMenuItem, Me.CargarGravedadEspecificaToolStripMenuItem, Me.CargarHumedadesToolStripMenuItem, Me.FundiciónToolStripMenuItem, Me.PieDeBandaToolStripMenuItem, Me.ExportFlujosToolStripMenuItem, Me.NovedadesToolStripMenuItem, Me.BalanceMetalurgicoToolStripMenuItem})
        Me.PlantaBeneficioToolStripMenuItem.Name = "PlantaBeneficioToolStripMenuItem"
        Me.PlantaBeneficioToolStripMenuItem.Size = New System.Drawing.Size(128, 24)
        Me.PlantaBeneficioToolStripMenuItem.Text = "Planta Beneficio"
        '
        'MineralPlantToolStripMenuItem
        '
        Me.MineralPlantToolStripMenuItem.Name = "MineralPlantToolStripMenuItem"
        Me.MineralPlantToolStripMenuItem.Size = New System.Drawing.Size(294, 24)
        Me.MineralPlantToolStripMenuItem.Text = "MineralPlant"
        '
        'DespacharMuestraLabToolStripMenuItem
        '
        Me.DespacharMuestraLabToolStripMenuItem.Name = "DespacharMuestraLabToolStripMenuItem"
        Me.DespacharMuestraLabToolStripMenuItem.Size = New System.Drawing.Size(294, 24)
        Me.DespacharMuestraLabToolStripMenuItem.Text = "Despachar Muestra Lab."
        '
        'CargarAnalisisQuimicosToolStripMenuItem
        '
        Me.CargarAnalisisQuimicosToolStripMenuItem.Name = "CargarAnalisisQuimicosToolStripMenuItem"
        Me.CargarAnalisisQuimicosToolStripMenuItem.Size = New System.Drawing.Size(294, 24)
        Me.CargarAnalisisQuimicosToolStripMenuItem.Text = "Cargar Analisis Quimicos SGS"
        '
        'CargarAnalisisQuimicosZandorToolStripMenuItem
        '
        Me.CargarAnalisisQuimicosZandorToolStripMenuItem.Name = "CargarAnalisisQuimicosZandorToolStripMenuItem"
        Me.CargarAnalisisQuimicosZandorToolStripMenuItem.Size = New System.Drawing.Size(294, 24)
        Me.CargarAnalisisQuimicosZandorToolStripMenuItem.Text = "Cargar Analisis Quimicos Zandor"
        '
        'GravedadEspecificaToolStripMenuItem
        '
        Me.GravedadEspecificaToolStripMenuItem.Name = "GravedadEspecificaToolStripMenuItem"
        Me.GravedadEspecificaToolStripMenuItem.Size = New System.Drawing.Size(294, 24)
        Me.GravedadEspecificaToolStripMenuItem.Text = "Gravedad especifica"
        '
        'CargarGravedadEspecificaToolStripMenuItem
        '
        Me.CargarGravedadEspecificaToolStripMenuItem.Name = "CargarGravedadEspecificaToolStripMenuItem"
        Me.CargarGravedadEspecificaToolStripMenuItem.Size = New System.Drawing.Size(294, 24)
        Me.CargarGravedadEspecificaToolStripMenuItem.Text = "Cargar Gravedad Especifica"
        '
        'CargarHumedadesToolStripMenuItem
        '
        Me.CargarHumedadesToolStripMenuItem.Name = "CargarHumedadesToolStripMenuItem"
        Me.CargarHumedadesToolStripMenuItem.Size = New System.Drawing.Size(294, 24)
        Me.CargarHumedadesToolStripMenuItem.Text = "Cargar Humedad"
        '
        'FundiciónToolStripMenuItem
        '
        Me.FundiciónToolStripMenuItem.Name = "FundiciónToolStripMenuItem"
        Me.FundiciónToolStripMenuItem.Size = New System.Drawing.Size(294, 24)
        Me.FundiciónToolStripMenuItem.Text = "Fundición"
        '
        'PieDeBandaToolStripMenuItem
        '
        Me.PieDeBandaToolStripMenuItem.Name = "PieDeBandaToolStripMenuItem"
        Me.PieDeBandaToolStripMenuItem.Size = New System.Drawing.Size(294, 24)
        Me.PieDeBandaToolStripMenuItem.Text = "Pie de Banda"
        '
        'ExportFlujosToolStripMenuItem
        '
        Me.ExportFlujosToolStripMenuItem.Name = "ExportFlujosToolStripMenuItem"
        Me.ExportFlujosToolStripMenuItem.Size = New System.Drawing.Size(294, 24)
        Me.ExportFlujosToolStripMenuItem.Text = "export flujos"
        '
        'NovedadesToolStripMenuItem
        '
        Me.NovedadesToolStripMenuItem.Name = "NovedadesToolStripMenuItem"
        Me.NovedadesToolStripMenuItem.Size = New System.Drawing.Size(294, 24)
        Me.NovedadesToolStripMenuItem.Text = "Novedades"
        '
        'MinerasToolStripMenuItem
        '
        Me.MinerasToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MuestreoToolStripMenuItem, Me.ImportarBasculaToolStripMenuItem})
        Me.MinerasToolStripMenuItem.Name = "MinerasToolStripMenuItem"
        Me.MinerasToolStripMenuItem.Size = New System.Drawing.Size(73, 24)
        Me.MinerasToolStripMenuItem.Text = "Mineras"
        '
        'MuestreoToolStripMenuItem
        '
        Me.MuestreoToolStripMenuItem.Name = "MuestreoToolStripMenuItem"
        Me.MuestreoToolStripMenuItem.Size = New System.Drawing.Size(190, 24)
        Me.MuestreoToolStripMenuItem.Text = "Muestreo"
        '
        'ImportarBasculaToolStripMenuItem
        '
        Me.ImportarBasculaToolStripMenuItem.Name = "ImportarBasculaToolStripMenuItem"
        Me.ImportarBasculaToolStripMenuItem.Size = New System.Drawing.Size(190, 24)
        Me.ImportarBasculaToolStripMenuItem.Text = "Importar Bascula"
        '
        'ReportesToolStripMenuItem1
        '
        Me.ReportesToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MerrilCroweToolStripMenuItem, Me.AlimentoMolinoB12ToolStripMenuItem, Me.ReporteVertimientoToolStripMenuItem})
        Me.ReportesToolStripMenuItem1.Name = "ReportesToolStripMenuItem1"
        Me.ReportesToolStripMenuItem1.Size = New System.Drawing.Size(80, 24)
        Me.ReportesToolStripMenuItem1.Text = "Reportes"
        '
        'MerrilCroweToolStripMenuItem
        '
        Me.MerrilCroweToolStripMenuItem.Name = "MerrilCroweToolStripMenuItem"
        Me.MerrilCroweToolStripMenuItem.Size = New System.Drawing.Size(229, 24)
        Me.MerrilCroweToolStripMenuItem.Text = "Merril Crowe"
        '
        'AlimentoMolinoB12ToolStripMenuItem
        '
        Me.AlimentoMolinoB12ToolStripMenuItem.Name = "AlimentoMolinoB12ToolStripMenuItem"
        Me.AlimentoMolinoB12ToolStripMenuItem.Size = New System.Drawing.Size(229, 24)
        Me.AlimentoMolinoB12ToolStripMenuItem.Text = "Alimento Molino (B12)"
        '
        'ReporteVertimientoToolStripMenuItem
        '
        Me.ReporteVertimientoToolStripMenuItem.Name = "ReporteVertimientoToolStripMenuItem"
        Me.ReporteVertimientoToolStripMenuItem.Size = New System.Drawing.Size(229, 24)
        Me.ReporteVertimientoToolStripMenuItem.Text = "Reporte Vertimiento"
        '
        'FlujosToolStripMenuItem
        '
        Me.FlujosToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.IngresarDensidadToolStripMenuItem, Me.ReportesToolStripMenuItem, Me.ConfiguracionToolStripMenuItem, Me.MuestrasInstantaneasToolStripMenuItem, Me.ImportarInstantaneasToolStripMenuItem, Me.GranulometríaToolStripMenuItem, Me.ImportarSinExcelToolStripMenuItem})
        Me.FlujosToolStripMenuItem.Name = "FlujosToolStripMenuItem"
        Me.FlujosToolStripMenuItem.Size = New System.Drawing.Size(183, 24)
        Me.FlujosToolStripMenuItem.Text = "Laboratorio Metalurgico"
        '
        'IngresarDensidadToolStripMenuItem
        '
        Me.IngresarDensidadToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EspesadoresToolStripMenuItem, Me.AgitadoresToolStripMenuItem})
        Me.IngresarDensidadToolStripMenuItem.Name = "IngresarDensidadToolStripMenuItem"
        Me.IngresarDensidadToolStripMenuItem.Size = New System.Drawing.Size(223, 24)
        Me.IngresarDensidadToolStripMenuItem.Text = "Flujos"
        '
        'EspesadoresToolStripMenuItem
        '
        Me.EspesadoresToolStripMenuItem.Name = "EspesadoresToolStripMenuItem"
        Me.EspesadoresToolStripMenuItem.Size = New System.Drawing.Size(160, 24)
        Me.EspesadoresToolStripMenuItem.Text = "Espesadores"
        '
        'AgitadoresToolStripMenuItem
        '
        Me.AgitadoresToolStripMenuItem.Name = "AgitadoresToolStripMenuItem"
        Me.AgitadoresToolStripMenuItem.Size = New System.Drawing.Size(160, 24)
        Me.AgitadoresToolStripMenuItem.Text = "Agitadores"
        '
        'ReportesToolStripMenuItem
        '
        Me.ReportesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DensidadesToolStripMenuItem})
        Me.ReportesToolStripMenuItem.Name = "ReportesToolStripMenuItem"
        Me.ReportesToolStripMenuItem.Size = New System.Drawing.Size(223, 24)
        Me.ReportesToolStripMenuItem.Text = "Reportes"
        '
        'DensidadesToolStripMenuItem
        '
        Me.DensidadesToolStripMenuItem.Name = "DensidadesToolStripMenuItem"
        Me.DensidadesToolStripMenuItem.Size = New System.Drawing.Size(155, 24)
        Me.DensidadesToolStripMenuItem.Text = "Densidades"
        '
        'ConfiguracionToolStripMenuItem
        '
        Me.ConfiguracionToolStripMenuItem.Name = "ConfiguracionToolStripMenuItem"
        Me.ConfiguracionToolStripMenuItem.Size = New System.Drawing.Size(223, 24)
        Me.ConfiguracionToolStripMenuItem.Text = "Configuración"
        '
        'MuestrasInstantaneasToolStripMenuItem
        '
        Me.MuestrasInstantaneasToolStripMenuItem.Name = "MuestrasInstantaneasToolStripMenuItem"
        Me.MuestrasInstantaneasToolStripMenuItem.Size = New System.Drawing.Size(223, 24)
        Me.MuestrasInstantaneasToolStripMenuItem.Text = "Muestras Instantaneas"
        '
        'ImportarInstantaneasToolStripMenuItem
        '
        Me.ImportarInstantaneasToolStripMenuItem.Name = "ImportarInstantaneasToolStripMenuItem"
        Me.ImportarInstantaneasToolStripMenuItem.Size = New System.Drawing.Size(223, 24)
        Me.ImportarInstantaneasToolStripMenuItem.Text = "Importar Instantaneas"
        '
        'GranulometríaToolStripMenuItem
        '
        Me.GranulometríaToolStripMenuItem.Name = "GranulometríaToolStripMenuItem"
        Me.GranulometríaToolStripMenuItem.Size = New System.Drawing.Size(223, 24)
        Me.GranulometríaToolStripMenuItem.Text = "Granulometría"
        '
        'ImportarSinExcelToolStripMenuItem
        '
        Me.ImportarSinExcelToolStripMenuItem.Name = "ImportarSinExcelToolStripMenuItem"
        Me.ImportarSinExcelToolStripMenuItem.Size = New System.Drawing.Size(223, 24)
        Me.ImportarSinExcelToolStripMenuItem.Text = "importar sin excel"
        '
        'ConsumoReactivosToolStripMenuItem
        '
        Me.ConsumoReactivosToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ConsumoDiarioToolStripMenuItem, Me.AgregarReactivosToolStripMenuItem})
        Me.ConsumoReactivosToolStripMenuItem.Name = "ConsumoReactivosToolStripMenuItem"
        Me.ConsumoReactivosToolStripMenuItem.Size = New System.Drawing.Size(150, 24)
        Me.ConsumoReactivosToolStripMenuItem.Text = "Consumo Reactivos"
        '
        'ConsumoDiarioToolStripMenuItem
        '
        Me.ConsumoDiarioToolStripMenuItem.Name = "ConsumoDiarioToolStripMenuItem"
        Me.ConsumoDiarioToolStripMenuItem.Size = New System.Drawing.Size(199, 24)
        Me.ConsumoDiarioToolStripMenuItem.Text = "Consumo Diario"
        '
        'AgregarReactivosToolStripMenuItem
        '
        Me.AgregarReactivosToolStripMenuItem.Name = "AgregarReactivosToolStripMenuItem"
        Me.AgregarReactivosToolStripMenuItem.Size = New System.Drawing.Size(199, 24)
        Me.AgregarReactivosToolStripMenuItem.Text = "Agregar Reactivos"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.Label1.Location = New System.Drawing.Point(960, 41)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(61, 17)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Usuario:"
        '
        'LblUserName
        '
        Me.LblUserName.AutoSize = True
        Me.LblUserName.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.LblUserName.Location = New System.Drawing.Point(1163, 41)
        Me.LblUserName.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblUserName.Name = "LblUserName"
        Me.LblUserName.Size = New System.Drawing.Size(58, 17)
        Me.LblUserName.TabIndex = 2
        Me.LblUserName.Text = "Nombre"
        '
        'lbltipoflujo
        '
        Me.lbltipoflujo.AutoSize = True
        Me.lbltipoflujo.Location = New System.Drawing.Point(1167, 97)
        Me.lbltipoflujo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbltipoflujo.Name = "lbltipoflujo"
        Me.lbltipoflujo.Size = New System.Drawing.Size(57, 17)
        Me.lbltipoflujo.TabIndex = 3
        Me.lbltipoflujo.Text = "tipoflujo"
        Me.lbltipoflujo.Visible = False
        '
        'BalanceMetalurgicoToolStripMenuItem
        '
        Me.BalanceMetalurgicoToolStripMenuItem.Name = "BalanceMetalurgicoToolStripMenuItem"
        Me.BalanceMetalurgicoToolStripMenuItem.Size = New System.Drawing.Size(294, 24)
        Me.BalanceMetalurgicoToolStripMenuItem.Text = "Balance Metalurgico"
        '
        'FrmPrincipal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1370, 736)
        Me.Controls.Add(Me.lbltipoflujo)
        Me.Controls.Add(Me.LblUserName)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "FrmPrincipal"
        Me.Text = "Zandor Capital"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents LblUserName As System.Windows.Forms.Label
    Friend WithEvents PlantaBeneficioToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MineralPlantToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DespacharMuestraLabToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CargarAnalisisQuimicosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CargarAnalisisQuimicosZandorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MinerasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MuestreoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportesToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MerrilCroweToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AlimentoMolinoB12ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CargarHumedadesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FlujosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IngresarDensidadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EspesadoresToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AgitadoresToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lbltipoflujo As System.Windows.Forms.Label
    Friend WithEvents ConfiguracionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DensidadesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FundiciónToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PieDeBandaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MuestrasInstantaneasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImportarInstantaneasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ConsumoReactivosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ConsumoDiarioToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AgregarReactivosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CargarGravedadEspecificaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GranulometríaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GravedadEspecificaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExportFlujosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImportarSinExcelToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NovedadesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImportarBasculaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReporteVertimientoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BalanceMetalurgicoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
