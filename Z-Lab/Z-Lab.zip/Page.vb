﻿
Namespace System.Web.UI
    Public Class Page

    End Class
End Namespace
