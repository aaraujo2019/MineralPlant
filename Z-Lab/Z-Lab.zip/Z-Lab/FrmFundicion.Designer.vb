﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmFundicion
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmFundicion))
        Me.Label8 = New System.Windows.Forms.Label()
        Me.LblArea = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.LblUsuario = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.DtFecha = New System.Windows.Forms.DateTimePicker()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.CmbOrigen = New System.Windows.Forms.ComboBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.LblIdConsecutivo = New System.Windows.Forms.Label()
        Me.cmbperiodo = New System.Windows.Forms.ComboBox()
        Me.CmdGuardar = New System.Windows.Forms.Button()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TxtAgLey2 = New System.Windows.Forms.TextBox()
        Me.TxtAuLey2 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TxtAgLey1 = New System.Windows.Forms.TextBox()
        Me.TxtAuLey1 = New System.Windows.Forms.TextBox()
        Me.TxtPesoInicial = New System.Windows.Forms.TextBox()
        Me.TxtPesoFinal = New System.Windows.Forms.TextBox()
        Me.TxtIdBarra = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Dgfundicion = New System.Windows.Forms.DataGridView()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.LblLeyAg2 = New System.Windows.Forms.Label()
        Me.LblLeyAu2 = New System.Windows.Forms.Label()
        Me.LblLeyAg1 = New System.Windows.Forms.Label()
        Me.LblLeyau1 = New System.Windows.Forms.Label()
        Me.LblPesoFgr = New System.Windows.Forms.Label()
        Me.LblPesoIGr = New System.Windows.Forms.Label()
        Me.LblPesoFOnzas = New System.Windows.Forms.Label()
        Me.LblpesoIOz = New System.Windows.Forms.Label()
        Me.LblAgOz2 = New System.Windows.Forms.Label()
        Me.LblAuOzAu = New System.Windows.Forms.Label()
        Me.LblAgOz = New System.Windows.Forms.Label()
        Me.LblAuOz = New System.Windows.Forms.Label()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.CmdBuscar = New System.Windows.Forms.Button()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.cmbmes = New System.Windows.Forms.ComboBox()
        Me.cmbperiodo2 = New System.Windows.Forms.ComboBox()
        Me.cmbano = New System.Windows.Forms.ComboBox()
        Me.GroupBox2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.Dgfundicion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Lucida Calligraphy", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(396, 10)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(336, 36)
        Me.Label8.TabIndex = 32
        Me.Label8.Text = "Reporte De Fundición"
        '
        'LblArea
        '
        Me.LblArea.AutoSize = True
        Me.LblArea.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblArea.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.LblArea.Location = New System.Drawing.Point(372, 95)
        Me.LblArea.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblArea.Name = "LblArea"
        Me.LblArea.Size = New System.Drawing.Size(57, 17)
        Me.LblArea.TabIndex = 31
        Me.LblArea.Text = "Label6"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(181, 95)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(102, 17)
        Me.Label7.TabIndex = 30
        Me.Label7.Text = "Departamento:"
        '
        'LblUsuario
        '
        Me.LblUsuario.AutoSize = True
        Me.LblUsuario.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblUsuario.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.LblUsuario.Location = New System.Drawing.Point(372, 63)
        Me.LblUsuario.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblUsuario.Name = "LblUsuario"
        Me.LblUsuario.Size = New System.Drawing.Size(57, 17)
        Me.LblUsuario.TabIndex = 29
        Me.LblUsuario.Text = "Label5"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(181, 63)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(80, 17)
        Me.Label4.TabIndex = 28
        Me.Label4.Text = "Id. Usuario:"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.PictureBox1)
        Me.GroupBox2.Location = New System.Drawing.Point(72, 43)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox2.Size = New System.Drawing.Size(1243, 79)
        Me.GroupBox2.TabIndex = 33
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Datos de Usuario:"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Z_Lab.My.Resources.Resources.LogoGranColombiaGoldSmall
        Me.PictureBox1.Location = New System.Drawing.Point(916, 14)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(276, 62)
        Me.PictureBox1.TabIndex = 27
        Me.PictureBox1.TabStop = False
        '
        'DtFecha
        '
        Me.DtFecha.Location = New System.Drawing.Point(29, 39)
        Me.DtFecha.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.DtFecha.Name = "DtFecha"
        Me.DtFecha.Size = New System.Drawing.Size(265, 22)
        Me.DtFecha.TabIndex = 34
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label39)
        Me.GroupBox1.Controls.Add(Me.CmbOrigen)
        Me.GroupBox1.Controls.Add(Me.Label35)
        Me.GroupBox1.Controls.Add(Me.LblIdConsecutivo)
        Me.GroupBox1.Controls.Add(Me.cmbperiodo)
        Me.GroupBox1.Controls.Add(Me.CmdGuardar)
        Me.GroupBox1.Controls.Add(Me.Label18)
        Me.GroupBox1.Controls.Add(Me.Label17)
        Me.GroupBox1.Controls.Add(Me.Label16)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.TxtAgLey2)
        Me.GroupBox1.Controls.Add(Me.TxtAuLey2)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.TxtAgLey1)
        Me.GroupBox1.Controls.Add(Me.TxtAuLey1)
        Me.GroupBox1.Controls.Add(Me.TxtPesoInicial)
        Me.GroupBox1.Controls.Add(Me.TxtPesoFinal)
        Me.GroupBox1.Controls.Add(Me.TxtIdBarra)
        Me.GroupBox1.Controls.Add(Me.Panel1)
        Me.GroupBox1.Location = New System.Drawing.Point(72, 252)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Size = New System.Drawing.Size(1283, 142)
        Me.GroupBox1.TabIndex = 57
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "BULLION DORE"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Label39.Location = New System.Drawing.Point(1057, 52)
        Me.Label39.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(62, 17)
        Me.Label39.TabIndex = 89
        Me.Label39.Text = "Origen:"
        '
        'CmbOrigen
        '
        Me.CmbOrigen.FormattingEnabled = True
        Me.CmbOrigen.Items.AddRange(New Object() {"CONCENTRADOR", "PRECIPITADO"})
        Me.CmbOrigen.Location = New System.Drawing.Point(1061, 91)
        Me.CmbOrigen.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CmbOrigen.Name = "CmbOrigen"
        Me.CmbOrigen.Size = New System.Drawing.Size(101, 24)
        Me.CmbOrigen.TabIndex = 88
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Label35.Location = New System.Drawing.Point(932, 52)
        Me.Label35.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(69, 17)
        Me.Label35.TabIndex = 80
        Me.Label35.Text = "Periodo:"
        '
        'LblIdConsecutivo
        '
        Me.LblIdConsecutivo.AutoSize = True
        Me.LblIdConsecutivo.Location = New System.Drawing.Point(24, 30)
        Me.LblIdConsecutivo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblIdConsecutivo.Name = "LblIdConsecutivo"
        Me.LblIdConsecutivo.Size = New System.Drawing.Size(23, 17)
        Me.LblIdConsecutivo.TabIndex = 59
        Me.LblIdConsecutivo.Text = "---"
        '
        'cmbperiodo
        '
        Me.cmbperiodo.FormattingEnabled = True
        Me.cmbperiodo.Items.AddRange(New Object() {"PERIODO1", "PERIODO2", "PERIODO3", "PERIODO4", "PERIODO5"})
        Me.cmbperiodo.Location = New System.Drawing.Point(936, 91)
        Me.cmbperiodo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmbperiodo.Name = "cmbperiodo"
        Me.cmbperiodo.Size = New System.Drawing.Size(116, 24)
        Me.cmbperiodo.TabIndex = 78
        '
        'CmdGuardar
        '
        Me.CmdGuardar.Location = New System.Drawing.Point(1175, 87)
        Me.CmdGuardar.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CmdGuardar.Name = "CmdGuardar"
        Me.CmdGuardar.Size = New System.Drawing.Size(100, 28)
        Me.CmdGuardar.TabIndex = 79
        Me.CmdGuardar.Text = "Guardar"
        Me.CmdGuardar.UseVisualStyleBackColor = True
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.ForeColor = System.Drawing.SystemColors.ButtonShadow
        Me.Label18.Location = New System.Drawing.Point(833, 71)
        Me.Label18.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(20, 17)
        Me.Label18.TabIndex = 78
        Me.Label18.Text = "%"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.ForeColor = System.Drawing.SystemColors.ButtonShadow
        Me.Label17.Location = New System.Drawing.Point(681, 71)
        Me.Label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(20, 17)
        Me.Label17.TabIndex = 77
        Me.Label17.Text = "%"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.ForeColor = System.Drawing.SystemColors.ButtonShadow
        Me.Label16.Location = New System.Drawing.Point(435, 71)
        Me.Label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(20, 17)
        Me.Label16.TabIndex = 76
        Me.Label16.Text = "%"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.ForeColor = System.Drawing.SystemColors.ButtonShadow
        Me.Label15.Location = New System.Drawing.Point(561, 71)
        Me.Label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(20, 17)
        Me.Label15.TabIndex = 75
        Me.Label15.Text = "%"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.ForeColor = System.Drawing.SystemColors.ButtonShadow
        Me.Label14.Location = New System.Drawing.Point(145, 71)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(58, 17)
        Me.Label14.TabIndex = 74
        Me.Label14.Text = "Gramos"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.ForeColor = System.Drawing.SystemColors.ButtonShadow
        Me.Label13.Location = New System.Drawing.Point(285, 71)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(58, 17)
        Me.Label13.TabIndex = 73
        Me.Label13.Text = "Gramos"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(673, 52)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(58, 17)
        Me.Label9.TabIndex = 70
        Me.Label9.Text = "Ley Au"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(807, 52)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(58, 17)
        Me.Label10.TabIndex = 69
        Me.Label10.Text = "Ley Ag"
        '
        'TxtAgLey2
        '
        Me.TxtAgLey2.Location = New System.Drawing.Point(811, 91)
        Me.TxtAgLey2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TxtAgLey2.Name = "TxtAgLey2"
        Me.TxtAgLey2.Size = New System.Drawing.Size(105, 22)
        Me.TxtAgLey2.TabIndex = 7
        '
        'TxtAuLey2
        '
        Me.TxtAuLey2.Location = New System.Drawing.Point(677, 91)
        Me.TxtAuLey2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TxtAuLey2.Name = "TxtAuLey2"
        Me.TxtAuLey2.Size = New System.Drawing.Size(105, 22)
        Me.TxtAuLey2.TabIndex = 6
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(421, 52)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(58, 17)
        Me.Label6.TabIndex = 66
        Me.Label6.Text = "Ley Au"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(543, 52)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(58, 17)
        Me.Label5.TabIndex = 65
        Me.Label5.Text = "Ley Ag"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(275, 52)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(84, 17)
        Me.Label3.TabIndex = 64
        Me.Label3.Text = "Peso Final"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(120, 52)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(91, 17)
        Me.Label2.TabIndex = 63
        Me.Label2.Text = "Peso Inicial"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(-1, 71)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(58, 17)
        Me.Label1.TabIndex = 62
        Me.Label1.Text = "Id Barra"
        '
        'TxtAgLey1
        '
        Me.TxtAgLey1.Location = New System.Drawing.Point(547, 91)
        Me.TxtAgLey1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TxtAgLey1.Name = "TxtAgLey1"
        Me.TxtAgLey1.Size = New System.Drawing.Size(105, 22)
        Me.TxtAgLey1.TabIndex = 5
        '
        'TxtAuLey1
        '
        Me.TxtAuLey1.Location = New System.Drawing.Point(425, 91)
        Me.TxtAuLey1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TxtAuLey1.Name = "TxtAuLey1"
        Me.TxtAuLey1.Size = New System.Drawing.Size(105, 22)
        Me.TxtAuLey1.TabIndex = 4
        '
        'TxtPesoInicial
        '
        Me.TxtPesoInicial.Location = New System.Drawing.Point(124, 91)
        Me.TxtPesoInicial.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TxtPesoInicial.Name = "TxtPesoInicial"
        Me.TxtPesoInicial.Size = New System.Drawing.Size(132, 22)
        Me.TxtPesoInicial.TabIndex = 2
        '
        'TxtPesoFinal
        '
        Me.TxtPesoFinal.Location = New System.Drawing.Point(279, 91)
        Me.TxtPesoFinal.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TxtPesoFinal.Name = "TxtPesoFinal"
        Me.TxtPesoFinal.Size = New System.Drawing.Size(132, 22)
        Me.TxtPesoFinal.TabIndex = 3
        '
        'TxtIdBarra
        '
        Me.TxtIdBarra.Location = New System.Drawing.Point(3, 91)
        Me.TxtIdBarra.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TxtIdBarra.Name = "TxtIdBarra"
        Me.TxtIdBarra.Size = New System.Drawing.Size(105, 22)
        Me.TxtIdBarra.TabIndex = 1
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.Label12)
        Me.Panel1.Location = New System.Drawing.Point(425, 18)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(492, 30)
        Me.Panel1.TabIndex = 80
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(33, 5)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(95, 20)
        Me.Label11.TabIndex = 71
        Me.Label11.Text = "Ley Inicial"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(283, 5)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(86, 20)
        Me.Label12.TabIndex = 72
        Me.Label12.Text = "Ley Final"
        '
        'Dgfundicion
        '
        Me.Dgfundicion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgfundicion.Location = New System.Drawing.Point(72, 418)
        Me.Dgfundicion.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Dgfundicion.Name = "Dgfundicion"
        Me.Dgfundicion.Size = New System.Drawing.Size(1243, 267)
        Me.Dgfundicion.TabIndex = 58
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(481, 36)
        Me.Label21.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(127, 20)
        Me.Label21.TabIndex = 61
        Me.Label21.Text = "Contenido Au:"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(646, 36)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(127, 20)
        Me.Label22.TabIndex = 62
        Me.Label22.Text = "Contenido Ag:"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(840, 36)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(127, 20)
        Me.Label23.TabIndex = 63
        Me.Label23.Text = "Contenido Au:"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(1021, 36)
        Me.Label24.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(127, 20)
        Me.Label24.TabIndex = 64
        Me.Label24.Text = "Contenido Ag:"
        '
        'LblLeyAg2
        '
        Me.LblLeyAg2.AutoSize = True
        Me.LblLeyAg2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLeyAg2.Location = New System.Drawing.Point(1021, 62)
        Me.LblLeyAg2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblLeyAg2.Name = "LblLeyAg2"
        Me.LblLeyAg2.Size = New System.Drawing.Size(27, 20)
        Me.LblLeyAg2.TabIndex = 70
        Me.LblLeyAg2.Text = "00"
        '
        'LblLeyAu2
        '
        Me.LblLeyAu2.AutoSize = True
        Me.LblLeyAu2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLeyAu2.Location = New System.Drawing.Point(840, 62)
        Me.LblLeyAu2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblLeyAu2.Name = "LblLeyAu2"
        Me.LblLeyAu2.Size = New System.Drawing.Size(27, 20)
        Me.LblLeyAu2.TabIndex = 69
        Me.LblLeyAu2.Text = "00"
        '
        'LblLeyAg1
        '
        Me.LblLeyAg1.AutoSize = True
        Me.LblLeyAg1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLeyAg1.Location = New System.Drawing.Point(646, 62)
        Me.LblLeyAg1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblLeyAg1.Name = "LblLeyAg1"
        Me.LblLeyAg1.Size = New System.Drawing.Size(27, 20)
        Me.LblLeyAg1.TabIndex = 68
        Me.LblLeyAg1.Text = "00"
        '
        'LblLeyau1
        '
        Me.LblLeyau1.AutoSize = True
        Me.LblLeyau1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblLeyau1.Location = New System.Drawing.Point(481, 62)
        Me.LblLeyau1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblLeyau1.Name = "LblLeyau1"
        Me.LblLeyau1.Size = New System.Drawing.Size(27, 20)
        Me.LblLeyau1.TabIndex = 67
        Me.LblLeyau1.Text = "00"
        '
        'LblPesoFgr
        '
        Me.LblPesoFgr.AutoSize = True
        Me.LblPesoFgr.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblPesoFgr.Location = New System.Drawing.Point(284, 62)
        Me.LblPesoFgr.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblPesoFgr.Name = "LblPesoFgr"
        Me.LblPesoFgr.Size = New System.Drawing.Size(27, 20)
        Me.LblPesoFgr.TabIndex = 66
        Me.LblPesoFgr.Text = "00"
        '
        'LblPesoIGr
        '
        Me.LblPesoIGr.AutoSize = True
        Me.LblPesoIGr.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblPesoIGr.Location = New System.Drawing.Point(118, 62)
        Me.LblPesoIGr.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblPesoIGr.Name = "LblPesoIGr"
        Me.LblPesoIGr.Size = New System.Drawing.Size(27, 20)
        Me.LblPesoIGr.TabIndex = 65
        Me.LblPesoIGr.Text = "00"
        '
        'LblPesoFOnzas
        '
        Me.LblPesoFOnzas.AutoSize = True
        Me.LblPesoFOnzas.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblPesoFOnzas.Location = New System.Drawing.Point(284, 146)
        Me.LblPesoFOnzas.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblPesoFOnzas.Name = "LblPesoFOnzas"
        Me.LblPesoFOnzas.Size = New System.Drawing.Size(29, 20)
        Me.LblPesoFOnzas.TabIndex = 72
        Me.LblPesoFOnzas.Text = "00"
        '
        'LblpesoIOz
        '
        Me.LblpesoIOz.AutoSize = True
        Me.LblpesoIOz.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblpesoIOz.Location = New System.Drawing.Point(118, 146)
        Me.LblpesoIOz.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblpesoIOz.Name = "LblpesoIOz"
        Me.LblpesoIOz.Size = New System.Drawing.Size(29, 20)
        Me.LblpesoIOz.TabIndex = 71
        Me.LblpesoIOz.Text = "00"
        '
        'LblAgOz2
        '
        Me.LblAgOz2.AutoSize = True
        Me.LblAgOz2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblAgOz2.Location = New System.Drawing.Point(1021, 146)
        Me.LblAgOz2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblAgOz2.Name = "LblAgOz2"
        Me.LblAgOz2.Size = New System.Drawing.Size(29, 20)
        Me.LblAgOz2.TabIndex = 76
        Me.LblAgOz2.Text = "00"
        '
        'LblAuOzAu
        '
        Me.LblAuOzAu.AutoSize = True
        Me.LblAuOzAu.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblAuOzAu.Location = New System.Drawing.Point(840, 146)
        Me.LblAuOzAu.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblAuOzAu.Name = "LblAuOzAu"
        Me.LblAuOzAu.Size = New System.Drawing.Size(29, 20)
        Me.LblAuOzAu.TabIndex = 75
        Me.LblAuOzAu.Text = "00"
        '
        'LblAgOz
        '
        Me.LblAgOz.AutoSize = True
        Me.LblAgOz.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblAgOz.Location = New System.Drawing.Point(646, 146)
        Me.LblAgOz.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblAgOz.Name = "LblAgOz"
        Me.LblAgOz.Size = New System.Drawing.Size(29, 20)
        Me.LblAgOz.TabIndex = 74
        Me.LblAgOz.Text = "00"
        '
        'LblAuOz
        '
        Me.LblAuOz.AutoSize = True
        Me.LblAuOz.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblAuOz.Location = New System.Drawing.Point(481, 146)
        Me.LblAuOz.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblAuOz.Name = "LblAuOz"
        Me.LblAuOz.Size = New System.Drawing.Size(29, 20)
        Me.LblAuOz.TabIndex = 73
        Me.LblAuOz.Text = "00"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset
        Me.TableLayoutPanel1.ColumnCount = 7
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.35088!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.64912!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 195.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 163.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 192.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 179.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 223.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.LblLeyAg2, 6, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label24, 6, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.LblLeyAu2, 5, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label23, 5, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.LblLeyAg1, 4, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label22, 4, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.LblLeyau1, 3, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label21, 3, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.LblPesoFgr, 2, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label20, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.LblPesoIGr, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label19, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label27, 5, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label25, 0, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.LblpesoIOz, 1, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.LblPesoFOnzas, 2, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.LblAuOz, 3, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.LblAgOz, 4, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.LblAuOzAu, 5, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.LblAgOz2, 6, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label28, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label29, 2, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label30, 3, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label31, 4, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label32, 5, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label33, 6, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label26, 3, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(72, 693)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 5
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 56.41026!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 43.58974!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 46.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1243, 182)
        Me.TableLayoutPanel1.TabIndex = 77
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(284, 36)
        Me.Label20.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(146, 20)
        Me.Label20.TabIndex = 62
        Me.Label20.Text = "Total Peso (Gr):"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(118, 36)
        Me.Label19.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(146, 20)
        Me.Label19.TabIndex = 60
        Me.Label19.Text = "Total Peso (Gr):"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.BackColor = System.Drawing.Color.DarkGray
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(840, 2)
        Me.Label27.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(146, 25)
        Me.Label27.TabIndex = 79
        Me.Label27.Text = "Laboratorio 2:"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(6, 146)
        Me.Label25.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(75, 34)
        Me.Label25.TabIndex = 77
        Me.Label25.Text = "Total Onzas"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(118, 110)
        Me.Label28.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(138, 34)
        Me.Label28.TabIndex = 80
        Me.Label28.Text = "Total Peso inicial (Oz):"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(284, 110)
        Me.Label29.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(168, 17)
        Me.Label29.TabIndex = 81
        Me.Label29.Text = "Total Peso Final (Oz):"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(481, 110)
        Me.Label30.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(97, 20)
        Me.Label30.TabIndex = 82
        Me.Label30.Text = "Onzas Au:"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(646, 110)
        Me.Label31.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(97, 20)
        Me.Label31.TabIndex = 83
        Me.Label31.Text = "Onzas Ag:"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(840, 110)
        Me.Label32.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(97, 20)
        Me.Label32.TabIndex = 84
        Me.Label32.Text = "Onzas Au:"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(1021, 110)
        Me.Label33.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(97, 20)
        Me.Label33.TabIndex = 85
        Me.Label33.Text = "Onzas Ag:"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.BackColor = System.Drawing.Color.DarkGray
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(481, 2)
        Me.Label26.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(146, 25)
        Me.Label26.TabIndex = 78
        Me.Label26.Text = "Laboratorio 1:"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(25, 20)
        Me.Label34.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(51, 17)
        Me.Label34.TabIndex = 79
        Me.Label34.Text = "Fecha:"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Button1)
        Me.GroupBox3.Controls.Add(Me.CmdBuscar)
        Me.GroupBox3.Controls.Add(Me.Label38)
        Me.GroupBox3.Controls.Add(Me.Label37)
        Me.GroupBox3.Controls.Add(Me.Label36)
        Me.GroupBox3.Controls.Add(Me.cmbmes)
        Me.GroupBox3.Controls.Add(Me.cmbperiodo2)
        Me.GroupBox3.Controls.Add(Me.cmbano)
        Me.GroupBox3.Controls.Add(Me.Label34)
        Me.GroupBox3.Controls.Add(Me.DtFecha)
        Me.GroupBox3.Location = New System.Drawing.Point(72, 151)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox3.Size = New System.Drawing.Size(1283, 94)
        Me.GroupBox3.TabIndex = 80
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Consultar Periodo:"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(1143, 41)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(100, 28)
        Me.Button1.TabIndex = 87
        Me.Button1.Text = "Exportar:"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'CmdBuscar
        '
        Me.CmdBuscar.Location = New System.Drawing.Point(993, 41)
        Me.CmdBuscar.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CmdBuscar.Name = "CmdBuscar"
        Me.CmdBuscar.Size = New System.Drawing.Size(100, 28)
        Me.CmdBuscar.TabIndex = 86
        Me.CmdBuscar.Text = "Buscar:"
        Me.CmdBuscar.UseVisualStyleBackColor = True
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(875, 20)
        Me.Label38.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(69, 17)
        Me.Label38.TabIndex = 85
        Me.Label38.Text = "Periodo:"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(749, 20)
        Me.Label37.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(42, 17)
        Me.Label37.TabIndex = 84
        Me.Label37.Text = "Mes:"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(608, 20)
        Me.Label36.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(41, 17)
        Me.Label36.TabIndex = 83
        Me.Label36.Text = "Año:"
        '
        'cmbmes
        '
        Me.cmbmes.FormattingEnabled = True
        Me.cmbmes.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"})
        Me.cmbmes.Location = New System.Drawing.Point(745, 43)
        Me.cmbmes.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmbmes.Name = "cmbmes"
        Me.cmbmes.Size = New System.Drawing.Size(105, 24)
        Me.cmbmes.TabIndex = 82
        '
        'cmbperiodo2
        '
        Me.cmbperiodo2.FormattingEnabled = True
        Me.cmbperiodo2.Items.AddRange(New Object() {"PERIODO1", "PERIODO2", "PERIODO3", "PERIODO4", "PERIODO5"})
        Me.cmbperiodo2.Location = New System.Drawing.Point(879, 43)
        Me.cmbperiodo2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmbperiodo2.Name = "cmbperiodo2"
        Me.cmbperiodo2.Size = New System.Drawing.Size(105, 24)
        Me.cmbperiodo2.TabIndex = 81
        '
        'cmbano
        '
        Me.cmbano.FormattingEnabled = True
        Me.cmbano.Location = New System.Drawing.Point(599, 43)
        Me.cmbano.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmbano.Name = "cmbano"
        Me.cmbano.Size = New System.Drawing.Size(105, 24)
        Me.cmbano.TabIndex = 80
        '
        'FrmFundicion
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.ClientSize = New System.Drawing.Size(1371, 923)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Controls.Add(Me.Dgfundicion)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.LblArea)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.LblUsuario)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.GroupBox2)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "FrmFundicion"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Fundición"
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.Dgfundicion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents LblArea As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents LblUsuario As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents DtFecha As System.Windows.Forms.DateTimePicker
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TxtAgLey2 As System.Windows.Forms.TextBox
    Friend WithEvents TxtAuLey2 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TxtAgLey1 As System.Windows.Forms.TextBox
    Friend WithEvents TxtAuLey1 As System.Windows.Forms.TextBox
    Friend WithEvents TxtPesoInicial As System.Windows.Forms.TextBox
    Friend WithEvents TxtPesoFinal As System.Windows.Forms.TextBox
    Friend WithEvents TxtIdBarra As System.Windows.Forms.TextBox
    Friend WithEvents Dgfundicion As System.Windows.Forms.DataGridView
    Friend WithEvents CmdGuardar As System.Windows.Forms.Button
    Friend WithEvents LblIdConsecutivo As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents LblLeyAg2 As System.Windows.Forms.Label
    Friend WithEvents LblLeyAu2 As System.Windows.Forms.Label
    Friend WithEvents LblLeyAg1 As System.Windows.Forms.Label
    Friend WithEvents LblLeyau1 As System.Windows.Forms.Label
    Friend WithEvents LblPesoFgr As System.Windows.Forms.Label
    Friend WithEvents LblPesoIGr As System.Windows.Forms.Label
    Friend WithEvents LblPesoFOnzas As System.Windows.Forms.Label
    Friend WithEvents LblpesoIOz As System.Windows.Forms.Label
    Friend WithEvents LblAgOz2 As System.Windows.Forms.Label
    Friend WithEvents LblAuOzAu As System.Windows.Forms.Label
    Friend WithEvents LblAgOz As System.Windows.Forms.Label
    Friend WithEvents LblAuOz As System.Windows.Forms.Label
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents cmbperiodo As System.Windows.Forms.ComboBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents CmdBuscar As System.Windows.Forms.Button
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents cmbmes As System.Windows.Forms.ComboBox
    Friend WithEvents cmbperiodo2 As System.Windows.Forms.ComboBox
    Friend WithEvents cmbano As System.Windows.Forms.ComboBox
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents CmbOrigen As System.Windows.Forms.ComboBox
End Class
