﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmMineralPlant
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmMineralPlant))
        Me.Label8 = New System.Windows.Forms.Label()
        Me.LblArea = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.LblUsuario = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.DateTimePickerFechaReporte = New System.Windows.Forms.DateTimePicker()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.ChkTimeView = New System.Windows.Forms.CheckBox()
        Me.CmbHoraFinal = New System.Windows.Forms.ComboBox()
        Me.CmbHoraInicio = New System.Windows.Forms.ComboBox()
        Me.Horometro = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.ChkTenor = New System.Windows.Forms.CheckBox()
        Me.LblExport = New System.Windows.Forms.Label()
        Me.DgSamplesDay = New System.Windows.Forms.DataGridView()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label96 = New System.Windows.Forms.Label()
        Me.TxtCommentSamples = New System.Windows.Forms.TextBox()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.ChkDup = New System.Windows.Forms.CheckBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Chk24hmuestras = New System.Windows.Forms.CheckBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.TxtDuplicado = New System.Windows.Forms.TextBox()
        Me.TxtSample = New System.Windows.Forms.TextBox()
        Me.CmdSaveMuestras = New System.Windows.Forms.Button()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.CmbSampleType = New System.Windows.Forms.ComboBox()
        Me.CmbLocation = New System.Windows.Forms.ComboBox()
        Me.ListHTo = New System.Windows.Forms.ListBox()
        Me.ListHFrom = New System.Windows.Forms.ListBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.LblOnzasEspe = New System.Windows.Forms.Label()
        Me.ChKFlotaLixiSolucion = New System.Windows.Forms.CheckBox()
        Me.LblTenorEspe = New System.Windows.Forms.Label()
        Me.LblTonseca = New System.Windows.Forms.Label()
        Me.ChkTenorFLixi = New System.Windows.Forms.CheckBox()
        Me.Label93 = New System.Windows.Forms.Label()
        Me.Label92 = New System.Windows.Forms.Label()
        Me.LblPorSolido = New System.Windows.Forms.Label()
        Me.LblPasante = New System.Windows.Forms.Label()
        Me.LblDensidad = New System.Windows.Forms.Label()
        Me.Label91 = New System.Windows.Forms.Label()
        Me.Label89 = New System.Windows.Forms.Label()
        Me.Label88 = New System.Windows.Forms.Label()
        Me.DgLixiviacion = New System.Windows.Forms.DataGridView()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.TxtLixiConcentrado = New System.Windows.Forms.TextBox()
        Me.TxtMCubicosH = New System.Windows.Forms.TextBox()
        Me.TxtGravedad = New System.Windows.Forms.TextBox()
        Me.TxtPorc_Pasante = New System.Windows.Forms.TextBox()
        Me.TxtDensidad = New System.Windows.Forms.TextBox()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.CmdGuardar = New System.Windows.Forms.Button()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.CmbFlujodeMasa = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ListHoraFinal = New System.Windows.Forms.ListBox()
        Me.ListHoraInicio = New System.Windows.Forms.ListBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.GroupBox24 = New System.Windows.Forms.GroupBox()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.DtFinalB12 = New System.Windows.Forms.DateTimePicker()
        Me.DtInicioB12 = New System.Windows.Forms.DateTimePicker()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.LblOnzas = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.ChkTenorBanda = New System.Windows.Forms.CheckBox()
        Me.LblAlimento = New System.Windows.Forms.Label()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.LblTenor = New System.Windows.Forms.Label()
        Me.LblHumedad = New System.Windows.Forms.Label()
        Me.LbltotalHumeda = New System.Windows.Forms.Label()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.LblTotalSeca = New System.Windows.Forms.Label()
        Me.DgLecturaBandas = New System.Windows.Forms.DataGridView()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.LblIdConsecutivo = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TxtMuestraBanda = New System.Windows.Forms.TextBox()
        Me.CmdSaveBanda = New System.Windows.Forms.Button()
        Me.Label95 = New System.Windows.Forms.Label()
        Me.txtToneladas = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.TxtPercHumedad = New System.Windows.Forms.TextBox()
        Me.TxtLecturaInicial = New System.Windows.Forms.TextBox()
        Me.TxtLecturaFinal = New System.Windows.Forms.TextBox()
        Me.ListB12Inicio = New System.Windows.Forms.ListBox()
        Me.ListB12Final = New System.Windows.Forms.ListBox()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.CmdReporteMineras = New System.Windows.Forms.Button()
        Me.LblExportar = New System.Windows.Forms.Label()
        Me.CmdExportDaily = New System.Windows.Forms.Button()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.DtFechaFinal = New System.Windows.Forms.DateTimePicker()
        Me.DtFechaInicio = New System.Windows.Forms.DateTimePicker()
        Me.CmdOperacionEdit = New System.Windows.Forms.Button()
        Me.CmdOperacion = New System.Windows.Forms.Button()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.TxtTonMinera = New System.Windows.Forms.TextBox()
        Me.TxtTonZandor = New System.Windows.Forms.TextBox()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.TxtStockPMFinos = New System.Windows.Forms.TextBox()
        Me.TxtStockZCGruesos = New System.Windows.Forms.TextBox()
        Me.TxtStockZCFinos = New System.Windows.Forms.TextBox()
        Me.TxtTonHumedasZC = New System.Windows.Forms.TextBox()
        Me.TxtTonhumedasPM = New System.Windows.Forms.TextBox()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.TxtFundicion = New System.Windows.Forms.TextBox()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.TxtOperacion = New System.Windows.Forms.TextBox()
        Me.TxtTonHora = New System.Windows.Forms.TextBox()
        Me.TxtHoras = New System.Windows.Forms.TextBox()
        Me.TxtMtto = New System.Windows.Forms.TextBox()
        Me.Txtconsumo = New System.Windows.Forms.TextBox()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.GroupBox25 = New System.Windows.Forms.GroupBox()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.DtFinalMerril = New System.Windows.Forms.DateTimePicker()
        Me.DtInicioMerril = New System.Windows.Forms.DateTimePicker()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.GroupBox13 = New System.Windows.Forms.GroupBox()
        Me.ChkResumerril = New System.Windows.Forms.CheckBox()
        Me.LblOzMerril = New System.Windows.Forms.Label()
        Me.LblTenorMerril = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.LbltonMerril = New System.Windows.Forms.Label()
        Me.DgMerrilCrowe = New System.Windows.Forms.DataGridView()
        Me.GroupBox12 = New System.Windows.Forms.GroupBox()
        Me.CmdSaveMC = New System.Windows.Forms.Button()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.TxtInicioMC = New System.Windows.Forms.TextBox()
        Me.TxTFinalMC = New System.Windows.Forms.TextBox()
        Me.ListMCInicio = New System.Windows.Forms.ListBox()
        Me.ListMCFinal = New System.Windows.Forms.ListBox()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.GroupBox22 = New System.Windows.Forms.GroupBox()
        Me.LblHorasMolienda = New System.Windows.Forms.Label()
        Me.Label118 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.DgHorometro = New System.Windows.Forms.DataGridView()
        Me.GroupBox14 = New System.Windows.Forms.GroupBox()
        Me.Label102 = New System.Windows.Forms.Label()
        Me.Label101 = New System.Windows.Forms.Label()
        Me.Label100 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Cmbturno = New System.Windows.Forms.ComboBox()
        Me.TxtLfinalHorometro = New System.Windows.Forms.TextBox()
        Me.TxtLinicialHorometro = New System.Windows.Forms.TextBox()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.GroupBox23 = New System.Windows.Forms.GroupBox()
        Me.LblHorasConcentrador = New System.Windows.Forms.Label()
        Me.Label114 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.DgHorometroKnelson = New System.Windows.Forms.DataGridView()
        Me.GroupBox15 = New System.Windows.Forms.GroupBox()
        Me.Label99 = New System.Windows.Forms.Label()
        Me.Label98 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label97 = New System.Windows.Forms.Label()
        Me.CmbKNelsonTurn = New System.Windows.Forms.ComboBox()
        Me.TxtHKNelsonF = New System.Windows.Forms.TextBox()
        Me.TxtHKNelsonI = New System.Windows.Forms.TextBox()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.GroupBox18 = New System.Windows.Forms.GroupBox()
        Me.CmdExportarFlowsE5 = New System.Windows.Forms.Button()
        Me.DtFinalE5 = New System.Windows.Forms.DateTimePicker()
        Me.DtInicioE5 = New System.Windows.Forms.DateTimePicker()
        Me.GroupBox17 = New System.Windows.Forms.GroupBox()
        Me.LblHorasE5 = New System.Windows.Forms.Label()
        Me.LblDensidadE5 = New System.Windows.Forms.Label()
        Me.Label106 = New System.Windows.Forms.Label()
        Me.Label107 = New System.Windows.Forms.Label()
        Me.Label108 = New System.Windows.Forms.Label()
        Me.LblTonsE5 = New System.Windows.Forms.Label()
        Me.DgFlujoE5 = New System.Windows.Forms.DataGridView()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.GroupBox16 = New System.Windows.Forms.GroupBox()
        Me.TxtHorasOperacione5 = New System.Windows.Forms.TextBox()
        Me.Label103 = New System.Windows.Forms.Label()
        Me.Label94 = New System.Windows.Forms.Label()
        Me.TxtDensidadE5 = New System.Windows.Forms.TextBox()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.CmbTurnoE5 = New System.Windows.Forms.ComboBox()
        Me.TxtFinalE5 = New System.Windows.Forms.TextBox()
        Me.TxtInicioE5 = New System.Windows.Forms.TextBox()
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.GroupBox20 = New System.Windows.Forms.GroupBox()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.DtFinalFl = New System.Windows.Forms.DateTimePicker()
        Me.DtInicioFl = New System.Windows.Forms.DateTimePicker()
        Me.GroupBox21 = New System.Windows.Forms.GroupBox()
        Me.LblHorasFlotacion = New System.Windows.Forms.Label()
        Me.LbldensidadFlotacion = New System.Windows.Forms.Label()
        Me.Label115 = New System.Windows.Forms.Label()
        Me.Label116 = New System.Windows.Forms.Label()
        Me.Label117 = New System.Windows.Forms.Label()
        Me.LbltonsFlotacion = New System.Windows.Forms.Label()
        Me.DgColasFlotacion = New System.Windows.Forms.DataGridView()
        Me.Label104 = New System.Windows.Forms.Label()
        Me.GroupBox19 = New System.Windows.Forms.GroupBox()
        Me.TxtHorasFl = New System.Windows.Forms.TextBox()
        Me.Label105 = New System.Windows.Forms.Label()
        Me.Label109 = New System.Windows.Forms.Label()
        Me.TxtDensidadFl = New System.Windows.Forms.TextBox()
        Me.Label110 = New System.Windows.Forms.Label()
        Me.Label111 = New System.Windows.Forms.Label()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Label112 = New System.Windows.Forms.Label()
        Me.CmbTurnoFl = New System.Windows.Forms.ComboBox()
        Me.TxtFinalFl = New System.Windows.Forms.TextBox()
        Me.TxtInicioFl = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.TxtHVertCep5 = New System.Windows.Forms.TextBox()
        Me.Label113 = New System.Windows.Forms.Label()
        Me.TxtHVertimientoFl = New System.Windows.Forms.TextBox()
        Me.Label119 = New System.Windows.Forms.Label()
        Me.Horometro.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DgSamplesDay, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.DgLixiviacion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.GroupBox24.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        CType(Me.DgLecturaBandas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.GroupBox25.SuspendLayout()
        Me.GroupBox13.SuspendLayout()
        CType(Me.DgMerrilCrowe, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox12.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.GroupBox22.SuspendLayout()
        CType(Me.DgHorometro, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox14.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.GroupBox23.SuspendLayout()
        CType(Me.DgHorometroKnelson, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox15.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        Me.GroupBox18.SuspendLayout()
        Me.GroupBox17.SuspendLayout()
        CType(Me.DgFlujoE5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox16.SuspendLayout()
        Me.TabPage9.SuspendLayout()
        Me.GroupBox20.SuspendLayout()
        Me.GroupBox21.SuspendLayout()
        CType(Me.DgColasFlotacion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox19.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Lucida Calligraphy", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(441, 14)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(557, 36)
        Me.Label8.TabIndex = 25
        Me.Label8.Text = "Reporte Diario - Planta Maria Dama"
        '
        'LblArea
        '
        Me.LblArea.AutoSize = True
        Me.LblArea.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblArea.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.LblArea.Location = New System.Drawing.Point(417, 98)
        Me.LblArea.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblArea.Name = "LblArea"
        Me.LblArea.Size = New System.Drawing.Size(57, 17)
        Me.LblArea.TabIndex = 24
        Me.LblArea.Text = "Label6"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(227, 98)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(102, 17)
        Me.Label7.TabIndex = 23
        Me.Label7.Text = "Departamento:"
        '
        'LblUsuario
        '
        Me.LblUsuario.AutoSize = True
        Me.LblUsuario.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblUsuario.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.LblUsuario.Location = New System.Drawing.Point(417, 66)
        Me.LblUsuario.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblUsuario.Name = "LblUsuario"
        Me.LblUsuario.Size = New System.Drawing.Size(57, 17)
        Me.LblUsuario.TabIndex = 22
        Me.LblUsuario.Text = "Label5"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(227, 66)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(80, 17)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "Id. Usuario:"
        '
        'GroupBox2
        '
        Me.GroupBox2.Location = New System.Drawing.Point(117, 47)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox2.Size = New System.Drawing.Size(1096, 79)
        Me.GroupBox2.TabIndex = 26
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Datos de Usuario:"
        '
        'DateTimePickerFechaReporte
        '
        Me.DateTimePickerFechaReporte.Location = New System.Drawing.Point(256, 174)
        Me.DateTimePickerFechaReporte.Margin = New System.Windows.Forms.Padding(4)
        Me.DateTimePickerFechaReporte.Name = "DateTimePickerFechaReporte"
        Me.DateTimePickerFechaReporte.Size = New System.Drawing.Size(265, 22)
        Me.DateTimePickerFechaReporte.TabIndex = 27
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(641, 174)
        Me.Label46.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(69, 17)
        Me.Label46.TabIndex = 40
        Me.Label46.Text = "Ver Hora:"
        '
        'ChkTimeView
        '
        Me.ChkTimeView.AutoSize = True
        Me.ChkTimeView.Location = New System.Drawing.Point(665, 194)
        Me.ChkTimeView.Margin = New System.Windows.Forms.Padding(4)
        Me.ChkTimeView.Name = "ChkTimeView"
        Me.ChkTimeView.Size = New System.Drawing.Size(18, 17)
        Me.ChkTimeView.TabIndex = 39
        Me.ChkTimeView.UseVisualStyleBackColor = True
        '
        'CmbHoraFinal
        '
        Me.CmbHoraFinal.FormattingEnabled = True
        Me.CmbHoraFinal.Location = New System.Drawing.Point(856, 180)
        Me.CmbHoraFinal.Margin = New System.Windows.Forms.Padding(4)
        Me.CmbHoraFinal.Name = "CmbHoraFinal"
        Me.CmbHoraFinal.Size = New System.Drawing.Size(105, 24)
        Me.CmbHoraFinal.TabIndex = 38
        Me.CmbHoraFinal.Visible = False
        '
        'CmbHoraInicio
        '
        Me.CmbHoraInicio.FormattingEnabled = True
        Me.CmbHoraInicio.Location = New System.Drawing.Point(739, 180)
        Me.CmbHoraInicio.Margin = New System.Windows.Forms.Padding(4)
        Me.CmbHoraInicio.Name = "CmbHoraInicio"
        Me.CmbHoraInicio.Size = New System.Drawing.Size(105, 24)
        Me.CmbHoraInicio.TabIndex = 37
        Me.CmbHoraInicio.Visible = False
        '
        'Horometro
        '
        Me.Horometro.Controls.Add(Me.TabPage1)
        Me.Horometro.Controls.Add(Me.TabPage2)
        Me.Horometro.Controls.Add(Me.TabPage3)
        Me.Horometro.Controls.Add(Me.TabPage4)
        Me.Horometro.Controls.Add(Me.TabPage5)
        Me.Horometro.Controls.Add(Me.TabPage6)
        Me.Horometro.Controls.Add(Me.TabPage7)
        Me.Horometro.Controls.Add(Me.TabPage8)
        Me.Horometro.Controls.Add(Me.TabPage9)
        Me.Horometro.Location = New System.Drawing.Point(35, 240)
        Me.Horometro.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Horometro.Name = "Horometro"
        Me.Horometro.SelectedIndex = 0
        Me.Horometro.Size = New System.Drawing.Size(1320, 622)
        Me.Horometro.TabIndex = 41
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.TabPage1.Controls.Add(Me.Label79)
        Me.TabPage1.Controls.Add(Me.PictureBox2)
        Me.TabPage1.Controls.Add(Me.ChkTenor)
        Me.TabPage1.Controls.Add(Me.LblExport)
        Me.TabPage1.Controls.Add(Me.DgSamplesDay)
        Me.TabPage1.Controls.Add(Me.GroupBox1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TabPage1.Size = New System.Drawing.Size(1312, 593)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Muestras"
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.Font = New System.Drawing.Font("Baskerville Old Face", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label79.Location = New System.Drawing.Point(211, 14)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(245, 32)
        Me.Label79.TabIndex = 66
        Me.Label79.Text = "Muestras de Planta"
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.Z_Lab.My.Resources.Resources.excel
        Me.PictureBox2.Location = New System.Drawing.Point(1173, 410)
        Me.PictureBox2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(56, 58)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox2.TabIndex = 65
        Me.PictureBox2.TabStop = False
        '
        'ChkTenor
        '
        Me.ChkTenor.AutoSize = True
        Me.ChkTenor.Location = New System.Drawing.Point(1152, 232)
        Me.ChkTenor.Margin = New System.Windows.Forms.Padding(4)
        Me.ChkTenor.Name = "ChkTenor"
        Me.ChkTenor.Size = New System.Drawing.Size(98, 21)
        Me.ChkTenor.TabIndex = 62
        Me.ChkTenor.Text = "Ver Tenor."
        Me.ChkTenor.UseVisualStyleBackColor = True
        '
        'LblExport
        '
        Me.LblExport.AutoSize = True
        Me.LblExport.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblExport.Location = New System.Drawing.Point(1120, 497)
        Me.LblExport.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblExport.Name = "LblExport"
        Me.LblExport.Size = New System.Drawing.Size(167, 29)
        Me.LblExport.TabIndex = 64
        Me.LblExport.Text = "Exportando..."
        Me.LblExport.Visible = False
        '
        'DgSamplesDay
        '
        Me.DgSamplesDay.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgSamplesDay.Location = New System.Drawing.Point(14, 229)
        Me.DgSamplesDay.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.DgSamplesDay.Name = "DgSamplesDay"
        Me.DgSamplesDay.RowTemplate.Height = 24
        Me.DgSamplesDay.Size = New System.Drawing.Size(1093, 356)
        Me.DgSamplesDay.TabIndex = 61
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label28)
        Me.GroupBox1.Controls.Add(Me.Label29)
        Me.GroupBox1.Controls.Add(Me.Label96)
        Me.GroupBox1.Controls.Add(Me.TxtCommentSamples)
        Me.GroupBox1.Controls.Add(Me.Label44)
        Me.GroupBox1.Controls.Add(Me.ChkDup)
        Me.GroupBox1.Controls.Add(Me.Label35)
        Me.GroupBox1.Controls.Add(Me.Chk24hmuestras)
        Me.GroupBox1.Controls.Add(Me.Label30)
        Me.GroupBox1.Controls.Add(Me.TxtDuplicado)
        Me.GroupBox1.Controls.Add(Me.TxtSample)
        Me.GroupBox1.Controls.Add(Me.CmdSaveMuestras)
        Me.GroupBox1.Controls.Add(Me.Label34)
        Me.GroupBox1.Controls.Add(Me.Label33)
        Me.GroupBox1.Controls.Add(Me.Label31)
        Me.GroupBox1.Controls.Add(Me.Label27)
        Me.GroupBox1.Controls.Add(Me.Label26)
        Me.GroupBox1.Controls.Add(Me.CmbSampleType)
        Me.GroupBox1.Controls.Add(Me.CmbLocation)
        Me.GroupBox1.Controls.Add(Me.ListHTo)
        Me.GroupBox1.Controls.Add(Me.ListHFrom)
        Me.GroupBox1.Location = New System.Drawing.Point(14, 48)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox1.Size = New System.Drawing.Size(1267, 167)
        Me.GroupBox1.TabIndex = 60
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Datos de Muestra:"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(299, 18)
        Me.Label28.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(179, 20)
        Me.Label28.TabIndex = 80
        Me.Label28.Text = "Intervalo de Tiempo."
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(635, 18)
        Me.Label29.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(236, 20)
        Me.Label29.TabIndex = 79
        Me.Label29.Text = "Descripcion de la Muestra."
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label96
        '
        Me.Label96.AutoSize = True
        Me.Label96.Location = New System.Drawing.Point(989, 53)
        Me.Label96.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label96.Name = "Label96"
        Me.Label96.Size = New System.Drawing.Size(91, 17)
        Me.Label96.TabIndex = 78
        Me.Label96.Text = "Comentarios:"
        '
        'TxtCommentSamples
        '
        Me.TxtCommentSamples.Location = New System.Drawing.Point(993, 73)
        Me.TxtCommentSamples.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtCommentSamples.Multiline = True
        Me.TxtCommentSamples.Name = "TxtCommentSamples"
        Me.TxtCommentSamples.Size = New System.Drawing.Size(156, 78)
        Me.TxtCommentSamples.TabIndex = 77
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(131, 50)
        Me.Label44.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(71, 17)
        Me.Label44.TabIndex = 76
        Me.Label44.Text = "Duplicado"
        '
        'ChkDup
        '
        Me.ChkDup.AutoSize = True
        Me.ChkDup.Location = New System.Drawing.Point(161, 78)
        Me.ChkDup.Margin = New System.Windows.Forms.Padding(4)
        Me.ChkDup.Name = "ChkDup"
        Me.ChkDup.Size = New System.Drawing.Size(18, 17)
        Me.ChkDup.TabIndex = 61
        Me.ChkDup.UseVisualStyleBackColor = True
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(211, 50)
        Me.Label35.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(66, 17)
        Me.Label35.TabIndex = 74
        Me.Label35.Text = "24 Horas"
        '
        'Chk24hmuestras
        '
        Me.Chk24hmuestras.AutoSize = True
        Me.Chk24hmuestras.Location = New System.Drawing.Point(229, 78)
        Me.Chk24hmuestras.Margin = New System.Windows.Forms.Padding(4)
        Me.Chk24hmuestras.Name = "Chk24hmuestras"
        Me.Chk24hmuestras.Size = New System.Drawing.Size(18, 17)
        Me.Chk24hmuestras.TabIndex = 62
        Me.Chk24hmuestras.UseVisualStyleBackColor = True
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(875, 50)
        Me.Label30.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(99, 17)
        Me.Label30.TabIndex = 75
        Me.Label30.Text = "Duplicado de :"
        '
        'TxtDuplicado
        '
        Me.TxtDuplicado.Location = New System.Drawing.Point(869, 73)
        Me.TxtDuplicado.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtDuplicado.Name = "TxtDuplicado"
        Me.TxtDuplicado.Size = New System.Drawing.Size(105, 22)
        Me.TxtDuplicado.TabIndex = 68
        '
        'TxtSample
        '
        Me.TxtSample.Location = New System.Drawing.Point(17, 74)
        Me.TxtSample.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtSample.Name = "TxtSample"
        Me.TxtSample.Size = New System.Drawing.Size(113, 22)
        Me.TxtSample.TabIndex = 60
        '
        'CmdSaveMuestras
        '
        Me.CmdSaveMuestras.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdSaveMuestras.Location = New System.Drawing.Point(1159, 78)
        Me.CmdSaveMuestras.Margin = New System.Windows.Forms.Padding(4)
        Me.CmdSaveMuestras.Name = "CmdSaveMuestras"
        Me.CmdSaveMuestras.Size = New System.Drawing.Size(91, 28)
        Me.CmdSaveMuestras.TabIndex = 73
        Me.CmdSaveMuestras.Text = "Guardar"
        Me.CmdSaveMuestras.UseVisualStyleBackColor = True
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(401, 50)
        Me.Label34.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(77, 17)
        Me.Label34.TabIndex = 72
        Me.Label34.Text = "Hora Final:"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(744, 50)
        Me.Label33.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(111, 17)
        Me.Label33.TabIndex = 71
        Me.Label33.Text = "Tipo de Muestra"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(511, 50)
        Me.Label31.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(70, 17)
        Me.Label31.TabIndex = 70
        Me.Label31.Text = "Ubicacion"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(283, 50)
        Me.Label27.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(79, 17)
        Me.Label27.TabIndex = 69
        Me.Label27.Text = "Hora Inicio:"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(43, 50)
        Me.Label26.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(59, 17)
        Me.Label26.TabIndex = 67
        Me.Label26.Text = "Muestra"
        '
        'CmbSampleType
        '
        Me.CmbSampleType.FormattingEnabled = True
        Me.CmbSampleType.Items.AddRange(New Object() {"Bandas", "Líquido", "Sólido", "Inventario"})
        Me.CmbSampleType.Location = New System.Drawing.Point(740, 73)
        Me.CmbSampleType.Margin = New System.Windows.Forms.Padding(4)
        Me.CmbSampleType.Name = "CmbSampleType"
        Me.CmbSampleType.Size = New System.Drawing.Size(115, 24)
        Me.CmbSampleType.TabIndex = 66
        '
        'CmbLocation
        '
        Me.CmbLocation.FormattingEnabled = True
        Me.CmbLocation.Location = New System.Drawing.Point(515, 73)
        Me.CmbLocation.Margin = New System.Windows.Forms.Padding(4)
        Me.CmbLocation.Name = "CmbLocation"
        Me.CmbLocation.Size = New System.Drawing.Size(209, 24)
        Me.CmbLocation.TabIndex = 65
        '
        'ListHTo
        '
        Me.ListHTo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListHTo.FormattingEnabled = True
        Me.ListHTo.ItemHeight = 20
        Me.ListHTo.Location = New System.Drawing.Point(393, 74)
        Me.ListHTo.Margin = New System.Windows.Forms.Padding(4)
        Me.ListHTo.Name = "ListHTo"
        Me.ListHTo.Size = New System.Drawing.Size(105, 24)
        Me.ListHTo.TabIndex = 64
        '
        'ListHFrom
        '
        Me.ListHFrom.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListHFrom.FormattingEnabled = True
        Me.ListHFrom.ItemHeight = 20
        Me.ListHFrom.Location = New System.Drawing.Point(277, 74)
        Me.ListHFrom.Margin = New System.Windows.Forms.Padding(4)
        Me.ListHFrom.Name = "ListHFrom"
        Me.ListHFrom.Size = New System.Drawing.Size(105, 24)
        Me.ListHFrom.TabIndex = 63
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.TabPage2.Controls.Add(Me.GroupBox4)
        Me.TabPage2.Controls.Add(Me.DgLixiviacion)
        Me.TabPage2.Controls.Add(Me.GroupBox3)
        Me.TabPage2.Location = New System.Drawing.Point(4, 25)
        Me.TabPage2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TabPage2.Size = New System.Drawing.Size(1312, 593)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Flotacion - Lixiviacion"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Label6)
        Me.GroupBox4.Controls.Add(Me.LblOnzasEspe)
        Me.GroupBox4.Controls.Add(Me.ChKFlotaLixiSolucion)
        Me.GroupBox4.Controls.Add(Me.LblTenorEspe)
        Me.GroupBox4.Controls.Add(Me.LblTonseca)
        Me.GroupBox4.Controls.Add(Me.ChkTenorFLixi)
        Me.GroupBox4.Controls.Add(Me.Label93)
        Me.GroupBox4.Controls.Add(Me.Label92)
        Me.GroupBox4.Controls.Add(Me.LblPorSolido)
        Me.GroupBox4.Controls.Add(Me.LblPasante)
        Me.GroupBox4.Controls.Add(Me.LblDensidad)
        Me.GroupBox4.Controls.Add(Me.Label91)
        Me.GroupBox4.Controls.Add(Me.Label89)
        Me.GroupBox4.Controls.Add(Me.Label88)
        Me.GroupBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.Location = New System.Drawing.Point(28, 482)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox4.Size = New System.Drawing.Size(1217, 90)
        Me.GroupBox4.TabIndex = 29
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Resumen:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label6.Location = New System.Drawing.Point(825, 30)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(54, 17)
        Me.Label6.TabIndex = 72
        Me.Label6.Text = "Onzas"
        '
        'LblOnzasEspe
        '
        Me.LblOnzasEspe.AutoSize = True
        Me.LblOnzasEspe.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblOnzasEspe.Location = New System.Drawing.Point(828, 55)
        Me.LblOnzasEspe.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblOnzasEspe.Name = "LblOnzasEspe"
        Me.LblOnzasEspe.Size = New System.Drawing.Size(49, 29)
        Me.LblOnzasEspe.TabIndex = 71
        Me.LblOnzasEspe.Text = "----"
        '
        'ChKFlotaLixiSolucion
        '
        Me.ChKFlotaLixiSolucion.AutoSize = True
        Me.ChKFlotaLixiSolucion.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChKFlotaLixiSolucion.Location = New System.Drawing.Point(996, 59)
        Me.ChKFlotaLixiSolucion.Margin = New System.Windows.Forms.Padding(4)
        Me.ChKFlotaLixiSolucion.Name = "ChKFlotaLixiSolucion"
        Me.ChKFlotaLixiSolucion.Size = New System.Drawing.Size(170, 21)
        Me.ChKFlotaLixiSolucion.TabIndex = 60
        Me.ChKFlotaLixiSolucion.Text = "Ver Tenor Solución"
        Me.ChKFlotaLixiSolucion.UseVisualStyleBackColor = True
        '
        'LblTenorEspe
        '
        Me.LblTenorEspe.AutoSize = True
        Me.LblTenorEspe.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTenorEspe.Location = New System.Drawing.Point(703, 55)
        Me.LblTenorEspe.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblTenorEspe.Name = "LblTenorEspe"
        Me.LblTenorEspe.Size = New System.Drawing.Size(49, 29)
        Me.LblTenorEspe.TabIndex = 70
        Me.LblTenorEspe.Text = "----"
        '
        'LblTonseca
        '
        Me.LblTonseca.AutoSize = True
        Me.LblTonseca.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTonseca.Location = New System.Drawing.Point(556, 55)
        Me.LblTonseca.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblTonseca.Name = "LblTonseca"
        Me.LblTonseca.Size = New System.Drawing.Size(49, 29)
        Me.LblTonseca.TabIndex = 59
        Me.LblTonseca.Text = "----"
        '
        'ChkTenorFLixi
        '
        Me.ChkTenorFLixi.AutoSize = True
        Me.ChkTenorFLixi.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChkTenorFLixi.Location = New System.Drawing.Point(996, 30)
        Me.ChkTenorFLixi.Margin = New System.Windows.Forms.Padding(4)
        Me.ChkTenorFLixi.Name = "ChkTenorFLixi"
        Me.ChkTenorFLixi.Size = New System.Drawing.Size(161, 21)
        Me.ChkTenorFLixi.TabIndex = 69
        Me.ChkTenorFLixi.Text = "Ver Tenor Sólidos"
        Me.ChkTenorFLixi.UseVisualStyleBackColor = True
        '
        'Label93
        '
        Me.Label93.AutoSize = True
        Me.Label93.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label93.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label93.Location = New System.Drawing.Point(691, 30)
        Me.Label93.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label93.Name = "Label93"
        Me.Label93.Size = New System.Drawing.Size(80, 17)
        Me.Label93.TabIndex = 68
        Me.Label93.Text = "Tenor Au."
        '
        'Label92
        '
        Me.Label92.AutoSize = True
        Me.Label92.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label92.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label92.Location = New System.Drawing.Point(543, 30)
        Me.Label92.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label92.Name = "Label92"
        Me.Label92.Size = New System.Drawing.Size(82, 17)
        Me.Label92.TabIndex = 67
        Me.Label92.Text = "Ton. Seca"
        '
        'LblPorSolido
        '
        Me.LblPorSolido.AutoSize = True
        Me.LblPorSolido.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblPorSolido.Location = New System.Drawing.Point(403, 55)
        Me.LblPorSolido.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblPorSolido.Name = "LblPorSolido"
        Me.LblPorSolido.Size = New System.Drawing.Size(49, 29)
        Me.LblPorSolido.TabIndex = 66
        Me.LblPorSolido.Text = "----"
        '
        'LblPasante
        '
        Me.LblPasante.AutoSize = True
        Me.LblPasante.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblPasante.Location = New System.Drawing.Point(231, 55)
        Me.LblPasante.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblPasante.Name = "LblPasante"
        Me.LblPasante.Size = New System.Drawing.Size(49, 29)
        Me.LblPasante.TabIndex = 65
        Me.LblPasante.Text = "----"
        '
        'LblDensidad
        '
        Me.LblDensidad.AutoSize = True
        Me.LblDensidad.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblDensidad.Location = New System.Drawing.Point(65, 55)
        Me.LblDensidad.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblDensidad.Name = "LblDensidad"
        Me.LblDensidad.Size = New System.Drawing.Size(49, 29)
        Me.LblDensidad.TabIndex = 64
        Me.LblDensidad.Text = "----"
        '
        'Label91
        '
        Me.Label91.AutoSize = True
        Me.Label91.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label91.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label91.Location = New System.Drawing.Point(368, 30)
        Me.Label91.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label91.Name = "Label91"
        Me.Label91.Size = New System.Drawing.Size(112, 17)
        Me.Label91.TabIndex = 63
        Me.Label91.Text = "% Peso Solido"
        '
        'Label89
        '
        Me.Label89.AutoSize = True
        Me.Label89.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label89.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label89.Location = New System.Drawing.Point(209, 30)
        Me.Label89.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(85, 17)
        Me.Label89.TabIndex = 62
        Me.Label89.Text = "% Pasante"
        '
        'Label88
        '
        Me.Label88.AutoSize = True
        Me.Label88.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label88.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label88.Location = New System.Drawing.Point(56, 30)
        Me.Label88.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(76, 17)
        Me.Label88.TabIndex = 61
        Me.Label88.Text = "Densidad"
        '
        'DgLixiviacion
        '
        Me.DgLixiviacion.AllowUserToAddRows = False
        Me.DgLixiviacion.AllowUserToDeleteRows = False
        Me.DgLixiviacion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgLixiviacion.Location = New System.Drawing.Point(28, 180)
        Me.DgLixiviacion.Margin = New System.Windows.Forms.Padding(4)
        Me.DgLixiviacion.Name = "DgLixiviacion"
        Me.DgLixiviacion.RowTemplate.Height = 24
        Me.DgLixiviacion.Size = New System.Drawing.Size(1220, 295)
        Me.DgLixiviacion.TabIndex = 28
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label77)
        Me.GroupBox3.Controls.Add(Me.Label76)
        Me.GroupBox3.Controls.Add(Me.TxtLixiConcentrado)
        Me.GroupBox3.Controls.Add(Me.TxtMCubicosH)
        Me.GroupBox3.Controls.Add(Me.TxtGravedad)
        Me.GroupBox3.Controls.Add(Me.TxtPorc_Pasante)
        Me.GroupBox3.Controls.Add(Me.TxtDensidad)
        Me.GroupBox3.Controls.Add(Me.Label75)
        Me.GroupBox3.Controls.Add(Me.Label70)
        Me.GroupBox3.Controls.Add(Me.Label63)
        Me.GroupBox3.Controls.Add(Me.Label62)
        Me.GroupBox3.Controls.Add(Me.Label24)
        Me.GroupBox3.Controls.Add(Me.Label23)
        Me.GroupBox3.Controls.Add(Me.CmdGuardar)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.Label14)
        Me.GroupBox3.Controls.Add(Me.Label13)
        Me.GroupBox3.Controls.Add(Me.Label10)
        Me.GroupBox3.Controls.Add(Me.CmbFlujodeMasa)
        Me.GroupBox3.Controls.Add(Me.Label5)
        Me.GroupBox3.Controls.Add(Me.ListHoraFinal)
        Me.GroupBox3.Controls.Add(Me.ListHoraInicio)
        Me.GroupBox3.Location = New System.Drawing.Point(15, 30)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox3.Size = New System.Drawing.Size(1267, 143)
        Me.GroupBox3.TabIndex = 0
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Datos de Ingreso"
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.Location = New System.Drawing.Point(1019, 66)
        Me.Label77.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(66, 17)
        Me.Label77.TabIndex = 58
        Me.Label77.Text = "Ton/hora"
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label76.Location = New System.Drawing.Point(1005, 30)
        Me.Label76.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(115, 20)
        Me.Label76.TabIndex = 61
        Me.Label76.Text = "Concentrado"
        '
        'TxtLixiConcentrado
        '
        Me.TxtLixiConcentrado.Location = New System.Drawing.Point(1013, 90)
        Me.TxtLixiConcentrado.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtLixiConcentrado.Name = "TxtLixiConcentrado"
        Me.TxtLixiConcentrado.Size = New System.Drawing.Size(75, 22)
        Me.TxtLixiConcentrado.TabIndex = 51
        '
        'TxtMCubicosH
        '
        Me.TxtMCubicosH.Location = New System.Drawing.Point(917, 90)
        Me.TxtMCubicosH.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtMCubicosH.Name = "TxtMCubicosH"
        Me.TxtMCubicosH.Size = New System.Drawing.Size(75, 22)
        Me.TxtMCubicosH.TabIndex = 50
        '
        'TxtGravedad
        '
        Me.TxtGravedad.Location = New System.Drawing.Point(815, 90)
        Me.TxtGravedad.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtGravedad.Name = "TxtGravedad"
        Me.TxtGravedad.Size = New System.Drawing.Size(75, 22)
        Me.TxtGravedad.TabIndex = 49
        '
        'TxtPorc_Pasante
        '
        Me.TxtPorc_Pasante.Location = New System.Drawing.Point(715, 89)
        Me.TxtPorc_Pasante.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtPorc_Pasante.Name = "TxtPorc_Pasante"
        Me.TxtPorc_Pasante.Size = New System.Drawing.Size(75, 22)
        Me.TxtPorc_Pasante.TabIndex = 48
        '
        'TxtDensidad
        '
        Me.TxtDensidad.Location = New System.Drawing.Point(605, 89)
        Me.TxtDensidad.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtDensidad.Name = "TxtDensidad"
        Me.TxtDensidad.Size = New System.Drawing.Size(75, 22)
        Me.TxtDensidad.TabIndex = 47
        '
        'Label75
        '
        Me.Label75.AutoSize = True
        Me.Label75.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label75.Location = New System.Drawing.Point(913, 30)
        Me.Label75.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(67, 20)
        Me.Label75.TabIndex = 65
        Me.Label75.Text = "Caudal"
        '
        'Label70
        '
        Me.Label70.AutoSize = True
        Me.Label70.Location = New System.Drawing.Point(925, 66)
        Me.Label70.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(57, 17)
        Me.Label70.TabIndex = 60
        Me.Label70.Text = "m³/hora"
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Location = New System.Drawing.Point(813, 73)
        Me.Label63.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(72, 17)
        Me.Label63.TabIndex = 64
        Me.Label63.Text = "Especifica"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Location = New System.Drawing.Point(813, 57)
        Me.Label62.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(71, 17)
        Me.Label62.TabIndex = 59
        Me.Label62.Text = "Gravedad"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(736, 66)
        Me.Label24.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(43, 17)
        Me.Label24.TabIndex = 63
        Me.Label24.Text = "74µm"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(697, 30)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(99, 20)
        Me.Label23.TabIndex = 62
        Me.Label23.Text = "% Pasante"
        '
        'CmdGuardar
        '
        Me.CmdGuardar.BackColor = System.Drawing.Color.Transparent
        Me.CmdGuardar.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdGuardar.ForeColor = System.Drawing.SystemColors.Desktop
        Me.CmdGuardar.Location = New System.Drawing.Point(1131, 82)
        Me.CmdGuardar.Margin = New System.Windows.Forms.Padding(4)
        Me.CmdGuardar.Name = "CmdGuardar"
        Me.CmdGuardar.Size = New System.Drawing.Size(100, 28)
        Me.CmdGuardar.TabIndex = 52
        Me.CmdGuardar.Text = "Guardar"
        Me.CmdGuardar.UseVisualStyleBackColor = False
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(485, 66)
        Me.Label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(73, 17)
        Me.Label15.TabIndex = 57
        Me.Label15.Text = "Hora Final"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(325, 66)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(75, 17)
        Me.Label14.TabIndex = 56
        Me.Label14.Text = "Hora Inicio"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(619, 66)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(53, 17)
        Me.Label13.TabIndex = 55
        Me.Label13.Text = "Ton/mᵌ"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(593, 31)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(88, 20)
        Me.Label10.TabIndex = 54
        Me.Label10.Text = "Densidad"
        '
        'CmbFlujodeMasa
        '
        Me.CmbFlujodeMasa.FormattingEnabled = True
        Me.CmbFlujodeMasa.Location = New System.Drawing.Point(13, 89)
        Me.CmbFlujodeMasa.Margin = New System.Windows.Forms.Padding(4)
        Me.CmbFlujodeMasa.Name = "CmbFlujodeMasa"
        Me.CmbFlujodeMasa.Size = New System.Drawing.Size(259, 24)
        Me.CmbFlujodeMasa.TabIndex = 44
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(325, 31)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(175, 20)
        Me.Label5.TabIndex = 53
        Me.Label5.Text = "Seleccione Horario."
        '
        'ListHoraFinal
        '
        Me.ListHoraFinal.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListHoraFinal.FormattingEnabled = True
        Me.ListHoraFinal.ItemHeight = 20
        Me.ListHoraFinal.Location = New System.Drawing.Point(468, 89)
        Me.ListHoraFinal.Margin = New System.Windows.Forms.Padding(4)
        Me.ListHoraFinal.Name = "ListHoraFinal"
        Me.ListHoraFinal.Size = New System.Drawing.Size(105, 24)
        Me.ListHoraFinal.TabIndex = 46
        '
        'ListHoraInicio
        '
        Me.ListHoraInicio.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListHoraInicio.FormattingEnabled = True
        Me.ListHoraInicio.ItemHeight = 20
        Me.ListHoraInicio.Location = New System.Drawing.Point(315, 89)
        Me.ListHoraInicio.Margin = New System.Windows.Forms.Padding(4)
        Me.ListHoraInicio.Name = "ListHoraInicio"
        Me.ListHoraInicio.Size = New System.Drawing.Size(105, 24)
        Me.ListHoraInicio.TabIndex = 45
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.TabPage3.Controls.Add(Me.GroupBox24)
        Me.TabPage3.Controls.Add(Me.Label78)
        Me.TabPage3.Controls.Add(Me.GroupBox6)
        Me.TabPage3.Controls.Add(Me.DgLecturaBandas)
        Me.TabPage3.Controls.Add(Me.GroupBox5)
        Me.TabPage3.Location = New System.Drawing.Point(4, 25)
        Me.TabPage3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TabPage3.Size = New System.Drawing.Size(1312, 593)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Lectura de Banda"
        '
        'GroupBox24
        '
        Me.GroupBox24.Controls.Add(Me.Button6)
        Me.GroupBox24.Controls.Add(Me.DtFinalB12)
        Me.GroupBox24.Controls.Add(Me.DtInicioB12)
        Me.GroupBox24.Location = New System.Drawing.Point(15, 497)
        Me.GroupBox24.Name = "GroupBox24"
        Me.GroupBox24.Size = New System.Drawing.Size(1264, 78)
        Me.GroupBox24.TabIndex = 46
        Me.GroupBox24.TabStop = False
        Me.GroupBox24.Text = "Exportar Datos"
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(802, 13)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(77, 31)
        Me.Button6.TabIndex = 2
        Me.Button6.Text = "Exportar"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'DtFinalB12
        '
        Me.DtFinalB12.Location = New System.Drawing.Point(423, 22)
        Me.DtFinalB12.Name = "DtFinalB12"
        Me.DtFinalB12.Size = New System.Drawing.Size(200, 22)
        Me.DtFinalB12.TabIndex = 1
        Me.DtFinalB12.Value = New Date(2017, 1, 1, 0, 0, 0, 0)
        '
        'DtInicioB12
        '
        Me.DtInicioB12.Location = New System.Drawing.Point(157, 22)
        Me.DtInicioB12.Name = "DtInicioB12"
        Me.DtInicioB12.Size = New System.Drawing.Size(200, 22)
        Me.DtInicioB12.TabIndex = 0
        Me.DtInicioB12.Value = New Date(2017, 1, 1, 0, 0, 0, 0)
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Font = New System.Drawing.Font("Baskerville Old Face", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label78.Location = New System.Drawing.Point(211, 15)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(391, 32)
        Me.Label78.TabIndex = 43
        Me.Label78.Text = "Lectura Pesometro - Banda 12."
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.LblOnzas)
        Me.GroupBox6.Controls.Add(Me.Label45)
        Me.GroupBox6.Controls.Add(Me.ChkTenorBanda)
        Me.GroupBox6.Controls.Add(Me.LblAlimento)
        Me.GroupBox6.Controls.Add(Me.Label86)
        Me.GroupBox6.Controls.Add(Me.LblTenor)
        Me.GroupBox6.Controls.Add(Me.LblHumedad)
        Me.GroupBox6.Controls.Add(Me.LbltotalHumeda)
        Me.GroupBox6.Controls.Add(Me.Label85)
        Me.GroupBox6.Controls.Add(Me.Label84)
        Me.GroupBox6.Controls.Add(Me.Label83)
        Me.GroupBox6.Controls.Add(Me.Label82)
        Me.GroupBox6.Controls.Add(Me.LblTotalSeca)
        Me.GroupBox6.Location = New System.Drawing.Point(15, 392)
        Me.GroupBox6.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox6.Size = New System.Drawing.Size(1264, 100)
        Me.GroupBox6.TabIndex = 17
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Resumen:"
        '
        'LblOnzas
        '
        Me.LblOnzas.AutoSize = True
        Me.LblOnzas.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblOnzas.Location = New System.Drawing.Point(965, 55)
        Me.LblOnzas.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblOnzas.Name = "LblOnzas"
        Me.LblOnzas.Size = New System.Drawing.Size(44, 26)
        Me.LblOnzas.TabIndex = 63
        Me.LblOnzas.Text = "----"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label45.Location = New System.Drawing.Point(931, 28)
        Me.Label45.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(96, 17)
        Me.Label45.TabIndex = 62
        Me.Label45.Text = "Total Onzas"
        '
        'ChkTenorBanda
        '
        Me.ChkTenorBanda.AutoSize = True
        Me.ChkTenorBanda.Enabled = False
        Me.ChkTenorBanda.Location = New System.Drawing.Point(1157, 55)
        Me.ChkTenorBanda.Margin = New System.Windows.Forms.Padding(4)
        Me.ChkTenorBanda.Name = "ChkTenorBanda"
        Me.ChkTenorBanda.Size = New System.Drawing.Size(94, 21)
        Me.ChkTenorBanda.TabIndex = 61
        Me.ChkTenorBanda.Text = "Ver Tenor"
        Me.ChkTenorBanda.UseVisualStyleBackColor = True
        '
        'LblAlimento
        '
        Me.LblAlimento.AutoSize = True
        Me.LblAlimento.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblAlimento.Location = New System.Drawing.Point(813, 55)
        Me.LblAlimento.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblAlimento.Name = "LblAlimento"
        Me.LblAlimento.Size = New System.Drawing.Size(44, 26)
        Me.LblAlimento.TabIndex = 60
        Me.LblAlimento.Text = "----"
        '
        'Label86
        '
        Me.Label86.AutoSize = True
        Me.Label86.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label86.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label86.Location = New System.Drawing.Point(771, 28)
        Me.Label86.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(106, 17)
        Me.Label86.TabIndex = 59
        Me.Label86.Text = "Total Gramos"
        '
        'LblTenor
        '
        Me.LblTenor.AutoSize = True
        Me.LblTenor.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTenor.Location = New System.Drawing.Point(652, 55)
        Me.LblTenor.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblTenor.Name = "LblTenor"
        Me.LblTenor.Size = New System.Drawing.Size(44, 26)
        Me.LblTenor.TabIndex = 58
        Me.LblTenor.Text = "----"
        '
        'LblHumedad
        '
        Me.LblHumedad.AutoSize = True
        Me.LblHumedad.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblHumedad.Location = New System.Drawing.Point(487, 55)
        Me.LblHumedad.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblHumedad.Name = "LblHumedad"
        Me.LblHumedad.Size = New System.Drawing.Size(44, 26)
        Me.LblHumedad.TabIndex = 57
        Me.LblHumedad.Text = "----"
        '
        'LbltotalHumeda
        '
        Me.LbltotalHumeda.AutoSize = True
        Me.LbltotalHumeda.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LbltotalHumeda.Location = New System.Drawing.Point(149, 55)
        Me.LbltotalHumeda.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LbltotalHumeda.Name = "LbltotalHumeda"
        Me.LbltotalHumeda.Size = New System.Drawing.Size(44, 26)
        Me.LbltotalHumeda.TabIndex = 56
        Me.LbltotalHumeda.Text = "----"
        '
        'Label85
        '
        Me.Label85.AutoSize = True
        Me.Label85.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label85.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label85.Location = New System.Drawing.Point(612, 28)
        Me.Label85.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(124, 17)
        Me.Label85.TabIndex = 55
        Me.Label85.Text = "Tenor Promedio"
        '
        'Label84
        '
        Me.Label84.AutoSize = True
        Me.Label84.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label84.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label84.Location = New System.Drawing.Point(456, 28)
        Me.Label84.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(94, 17)
        Me.Label84.TabIndex = 54
        Me.Label84.Text = "% Humedad"
        '
        'Label83
        '
        Me.Label83.AutoEllipsis = True
        Me.Label83.AutoSize = True
        Me.Label83.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label83.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label83.Location = New System.Drawing.Point(288, 28)
        Me.Label83.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(124, 17)
        Me.Label83.TabIndex = 53
        Me.Label83.Text = "Total Ton. Seca"
        '
        'Label82
        '
        Me.Label82.AutoSize = True
        Me.Label82.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label82.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label82.Location = New System.Drawing.Point(107, 28)
        Me.Label82.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(155, 17)
        Me.Label82.TabIndex = 52
        Me.Label82.Text = "Total Ton. Humedas"
        '
        'LblTotalSeca
        '
        Me.LblTotalSeca.AutoSize = True
        Me.LblTotalSeca.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTotalSeca.Location = New System.Drawing.Point(321, 55)
        Me.LblTotalSeca.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblTotalSeca.Name = "LblTotalSeca"
        Me.LblTotalSeca.Size = New System.Drawing.Size(44, 26)
        Me.LblTotalSeca.TabIndex = 51
        Me.LblTotalSeca.Text = "----"
        '
        'DgLecturaBandas
        '
        Me.DgLecturaBandas.AllowUserToAddRows = False
        Me.DgLecturaBandas.AllowUserToDeleteRows = False
        Me.DgLecturaBandas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgLecturaBandas.Location = New System.Drawing.Point(15, 148)
        Me.DgLecturaBandas.Margin = New System.Windows.Forms.Padding(4)
        Me.DgLecturaBandas.Name = "DgLecturaBandas"
        Me.DgLecturaBandas.ReadOnly = True
        Me.DgLecturaBandas.RowTemplate.Height = 24
        Me.DgLecturaBandas.Size = New System.Drawing.Size(1264, 238)
        Me.DgLecturaBandas.TabIndex = 16
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.LblIdConsecutivo)
        Me.GroupBox5.Controls.Add(Me.Label3)
        Me.GroupBox5.Controls.Add(Me.TxtMuestraBanda)
        Me.GroupBox5.Controls.Add(Me.CmdSaveBanda)
        Me.GroupBox5.Controls.Add(Me.Label95)
        Me.GroupBox5.Controls.Add(Me.txtToneladas)
        Me.GroupBox5.Controls.Add(Me.Label25)
        Me.GroupBox5.Controls.Add(Me.Label22)
        Me.GroupBox5.Controls.Add(Me.Label21)
        Me.GroupBox5.Controls.Add(Me.Label20)
        Me.GroupBox5.Controls.Add(Me.Label19)
        Me.GroupBox5.Controls.Add(Me.Label18)
        Me.GroupBox5.Controls.Add(Me.Label17)
        Me.GroupBox5.Controls.Add(Me.Label16)
        Me.GroupBox5.Controls.Add(Me.TxtPercHumedad)
        Me.GroupBox5.Controls.Add(Me.TxtLecturaInicial)
        Me.GroupBox5.Controls.Add(Me.TxtLecturaFinal)
        Me.GroupBox5.Controls.Add(Me.ListB12Inicio)
        Me.GroupBox5.Controls.Add(Me.ListB12Final)
        Me.GroupBox5.Location = New System.Drawing.Point(15, 42)
        Me.GroupBox5.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox5.Size = New System.Drawing.Size(1264, 100)
        Me.GroupBox5.TabIndex = 0
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Lectura de Banda:"
        '
        'LblIdConsecutivo
        '
        Me.LblIdConsecutivo.AutoSize = True
        Me.LblIdConsecutivo.Location = New System.Drawing.Point(1153, 22)
        Me.LblIdConsecutivo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblIdConsecutivo.Name = "LblIdConsecutivo"
        Me.LblIdConsecutivo.Size = New System.Drawing.Size(19, 17)
        Me.LblIdConsecutivo.TabIndex = 69
        Me.LblIdConsecutivo.Text = "Id"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(993, 18)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(124, 20)
        Me.Label3.TabIndex = 65
        Me.Label3.Text = "# de Muestra."
        '
        'TxtMuestraBanda
        '
        Me.TxtMuestraBanda.Location = New System.Drawing.Point(997, 66)
        Me.TxtMuestraBanda.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtMuestraBanda.Name = "TxtMuestraBanda"
        Me.TxtMuestraBanda.Size = New System.Drawing.Size(104, 22)
        Me.TxtMuestraBanda.TabIndex = 68
        '
        'CmdSaveBanda
        '
        Me.CmdSaveBanda.BackColor = System.Drawing.Color.Transparent
        Me.CmdSaveBanda.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdSaveBanda.ForeColor = System.Drawing.SystemColors.Desktop
        Me.CmdSaveBanda.Location = New System.Drawing.Point(1157, 64)
        Me.CmdSaveBanda.Margin = New System.Windows.Forms.Padding(4)
        Me.CmdSaveBanda.Name = "CmdSaveBanda"
        Me.CmdSaveBanda.Size = New System.Drawing.Size(100, 28)
        Me.CmdSaveBanda.TabIndex = 67
        Me.CmdSaveBanda.Text = "Guardar"
        Me.CmdSaveBanda.UseVisualStyleBackColor = False
        '
        'Label95
        '
        Me.Label95.AutoSize = True
        Me.Label95.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label95.Location = New System.Drawing.Point(717, 9)
        Me.Label95.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(100, 20)
        Me.Label95.TabIndex = 66
        Me.Label95.Text = "Toneladas."
        '
        'txtToneladas
        '
        Me.txtToneladas.Location = New System.Drawing.Point(723, 68)
        Me.txtToneladas.Margin = New System.Windows.Forms.Padding(4)
        Me.txtToneladas.Name = "txtToneladas"
        Me.txtToneladas.Size = New System.Drawing.Size(105, 22)
        Me.txtToneladas.TabIndex = 56
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(895, 37)
        Me.Label25.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(20, 17)
        Me.Label25.TabIndex = 65
        Me.Label25.Text = "%"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(867, 9)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(93, 20)
        Me.Label22.TabIndex = 64
        Me.Label22.Text = "Humedad."
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(109, 37)
        Me.Label21.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(79, 17)
        Me.Label21.TabIndex = 63
        Me.Label21.Text = "Hora Inicio:"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(451, 10)
        Me.Label20.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(169, 20)
        Me.Label20.TabIndex = 62
        Me.Label20.Text = "Lectura Pesometro"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(573, 37)
        Me.Label19.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(94, 17)
        Me.Label19.TabIndex = 61
        Me.Label19.Text = "Lectura Final:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(123, 10)
        Me.Label18.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(179, 20)
        Me.Label18.TabIndex = 60
        Me.Label18.Text = "Intervalo de Tiempo."
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(245, 37)
        Me.Label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(77, 17)
        Me.Label17.TabIndex = 59
        Me.Label17.Text = "Hora Final:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(435, 37)
        Me.Label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(99, 17)
        Me.Label16.TabIndex = 58
        Me.Label16.Text = "Lectura Inicial:"
        '
        'TxtPercHumedad
        '
        Me.TxtPercHumedad.Location = New System.Drawing.Point(868, 68)
        Me.TxtPercHumedad.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtPercHumedad.Name = "TxtPercHumedad"
        Me.TxtPercHumedad.Size = New System.Drawing.Size(105, 22)
        Me.TxtPercHumedad.TabIndex = 57
        Me.TxtPercHumedad.Text = " "
        '
        'TxtLecturaInicial
        '
        Me.TxtLecturaInicial.Location = New System.Drawing.Point(420, 68)
        Me.TxtLecturaInicial.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtLecturaInicial.Name = "TxtLecturaInicial"
        Me.TxtLecturaInicial.Size = New System.Drawing.Size(105, 22)
        Me.TxtLecturaInicial.TabIndex = 54
        '
        'TxtLecturaFinal
        '
        Me.TxtLecturaFinal.Location = New System.Drawing.Point(555, 68)
        Me.TxtLecturaFinal.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtLecturaFinal.Name = "TxtLecturaFinal"
        Me.TxtLecturaFinal.Size = New System.Drawing.Size(105, 22)
        Me.TxtLecturaFinal.TabIndex = 55
        '
        'ListB12Inicio
        '
        Me.ListB12Inicio.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListB12Inicio.FormattingEnabled = True
        Me.ListB12Inicio.ItemHeight = 20
        Me.ListB12Inicio.Location = New System.Drawing.Point(100, 68)
        Me.ListB12Inicio.Margin = New System.Windows.Forms.Padding(4)
        Me.ListB12Inicio.Name = "ListB12Inicio"
        Me.ListB12Inicio.Size = New System.Drawing.Size(105, 24)
        Me.ListB12Inicio.TabIndex = 52
        '
        'ListB12Final
        '
        Me.ListB12Final.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListB12Final.FormattingEnabled = True
        Me.ListB12Final.ItemHeight = 20
        Me.ListB12Final.Location = New System.Drawing.Point(235, 68)
        Me.ListB12Final.Margin = New System.Windows.Forms.Padding(4)
        Me.ListB12Final.Name = "ListB12Final"
        Me.ListB12Final.Size = New System.Drawing.Size(105, 24)
        Me.ListB12Final.TabIndex = 53
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.TabPage4.Controls.Add(Me.GroupBox11)
        Me.TabPage4.Controls.Add(Me.CmdOperacionEdit)
        Me.TabPage4.Controls.Add(Me.CmdOperacion)
        Me.TabPage4.Controls.Add(Me.GroupBox9)
        Me.TabPage4.Controls.Add(Me.GroupBox8)
        Me.TabPage4.Controls.Add(Me.GroupBox10)
        Me.TabPage4.Controls.Add(Me.GroupBox7)
        Me.TabPage4.Location = New System.Drawing.Point(4, 25)
        Me.TabPage4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TabPage4.Size = New System.Drawing.Size(1312, 593)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Operacion"
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.CmdReporteMineras)
        Me.GroupBox11.Controls.Add(Me.LblExportar)
        Me.GroupBox11.Controls.Add(Me.CmdExportDaily)
        Me.GroupBox11.Controls.Add(Me.Label49)
        Me.GroupBox11.Controls.Add(Me.Label47)
        Me.GroupBox11.Controls.Add(Me.DtFechaFinal)
        Me.GroupBox11.Controls.Add(Me.DtFechaInicio)
        Me.GroupBox11.Location = New System.Drawing.Point(15, 423)
        Me.GroupBox11.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox11.Size = New System.Drawing.Size(1236, 100)
        Me.GroupBox11.TabIndex = 25
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "Exportar Resumen Diario:"
        '
        'CmdReporteMineras
        '
        Me.CmdReporteMineras.Font = New System.Drawing.Font("Arial Narrow", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdReporteMineras.Location = New System.Drawing.Point(749, 16)
        Me.CmdReporteMineras.Margin = New System.Windows.Forms.Padding(4)
        Me.CmdReporteMineras.Name = "CmdReporteMineras"
        Me.CmdReporteMineras.Size = New System.Drawing.Size(83, 66)
        Me.CmdReporteMineras.TabIndex = 64
        Me.CmdReporteMineras.Text = "Mineras"
        Me.CmdReporteMineras.UseVisualStyleBackColor = True
        '
        'LblExportar
        '
        Me.LblExportar.AutoSize = True
        Me.LblExportar.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblExportar.Location = New System.Drawing.Point(1036, 51)
        Me.LblExportar.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblExportar.Name = "LblExportar"
        Me.LblExportar.Size = New System.Drawing.Size(176, 31)
        Me.LblExportar.TabIndex = 63
        Me.LblExportar.Text = "Exportando..."
        Me.LblExportar.Visible = False
        '
        'CmdExportDaily
        '
        Me.CmdExportDaily.Font = New System.Drawing.Font("Arial Narrow", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdExportDaily.Location = New System.Drawing.Point(604, 16)
        Me.CmdExportDaily.Margin = New System.Windows.Forms.Padding(4)
        Me.CmdExportDaily.Name = "CmdExportDaily"
        Me.CmdExportDaily.Size = New System.Drawing.Size(84, 66)
        Me.CmdExportDaily.TabIndex = 62
        Me.CmdExportDaily.Text = "Planta"
        Me.CmdExportDaily.UseVisualStyleBackColor = True
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(115, 66)
        Me.Label49.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(81, 17)
        Me.Label49.TabIndex = 61
        Me.Label49.Text = "Fecha Final"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(115, 25)
        Me.Label47.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(83, 17)
        Me.Label47.TabIndex = 60
        Me.Label47.Text = "Fecha Inicio"
        '
        'DtFechaFinal
        '
        Me.DtFechaFinal.Location = New System.Drawing.Point(240, 58)
        Me.DtFechaFinal.Margin = New System.Windows.Forms.Padding(4)
        Me.DtFechaFinal.Name = "DtFechaFinal"
        Me.DtFechaFinal.Size = New System.Drawing.Size(265, 22)
        Me.DtFechaFinal.TabIndex = 59
        Me.DtFechaFinal.Value = New Date(2017, 1, 1, 0, 0, 0, 0)
        '
        'DtFechaInicio
        '
        Me.DtFechaInicio.Location = New System.Drawing.Point(237, 16)
        Me.DtFechaInicio.Margin = New System.Windows.Forms.Padding(4)
        Me.DtFechaInicio.Name = "DtFechaInicio"
        Me.DtFechaInicio.Size = New System.Drawing.Size(265, 22)
        Me.DtFechaInicio.TabIndex = 58
        Me.DtFechaInicio.Value = New Date(2017, 1, 1, 0, 0, 0, 0)
        '
        'CmdOperacionEdit
        '
        Me.CmdOperacionEdit.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdOperacionEdit.Location = New System.Drawing.Point(32, 368)
        Me.CmdOperacionEdit.Margin = New System.Windows.Forms.Padding(4)
        Me.CmdOperacionEdit.Name = "CmdOperacionEdit"
        Me.CmdOperacionEdit.Size = New System.Drawing.Size(100, 28)
        Me.CmdOperacionEdit.TabIndex = 24
        Me.CmdOperacionEdit.Text = "Editar"
        Me.CmdOperacionEdit.UseVisualStyleBackColor = True
        '
        'CmdOperacion
        '
        Me.CmdOperacion.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdOperacion.Location = New System.Drawing.Point(196, 368)
        Me.CmdOperacion.Margin = New System.Windows.Forms.Padding(4)
        Me.CmdOperacion.Name = "CmdOperacion"
        Me.CmdOperacion.Size = New System.Drawing.Size(100, 28)
        Me.CmdOperacion.TabIndex = 23
        Me.CmdOperacion.Text = "Guardar"
        Me.CmdOperacion.UseVisualStyleBackColor = True
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.Label66)
        Me.GroupBox9.Controls.Add(Me.Label65)
        Me.GroupBox9.Controls.Add(Me.Label64)
        Me.GroupBox9.Controls.Add(Me.TxtTonMinera)
        Me.GroupBox9.Controls.Add(Me.TxtTonZandor)
        Me.GroupBox9.Location = New System.Drawing.Point(652, 206)
        Me.GroupBox9.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox9.Size = New System.Drawing.Size(599, 100)
        Me.GroupBox9.TabIndex = 3
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Toneladas Molidas:"
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.BackColor = System.Drawing.Color.Silver
        Me.Label66.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label66.Location = New System.Drawing.Point(301, 18)
        Me.Label66.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(70, 17)
        Me.Label66.TabIndex = 56
        Me.Label66.Text = "Mineras:"
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.BackColor = System.Drawing.Color.Silver
        Me.Label65.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label65.Location = New System.Drawing.Point(185, 18)
        Me.Label65.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(60, 17)
        Me.Label65.TabIndex = 55
        Me.Label65.Text = "Zandor"
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.Label64.Location = New System.Drawing.Point(213, 39)
        Me.Label64.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(77, 17)
        Me.Label64.TabIndex = 54
        Me.Label64.Text = "Ton. Seca:"
        '
        'TxtTonMinera
        '
        Me.TxtTonMinera.Location = New System.Drawing.Point(283, 60)
        Me.TxtTonMinera.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtTonMinera.Name = "TxtTonMinera"
        Me.TxtTonMinera.Size = New System.Drawing.Size(92, 22)
        Me.TxtTonMinera.TabIndex = 53
        '
        'TxtTonZandor
        '
        Me.TxtTonZandor.Location = New System.Drawing.Point(165, 60)
        Me.TxtTonZandor.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtTonZandor.Name = "TxtTonZandor"
        Me.TxtTonZandor.Size = New System.Drawing.Size(92, 22)
        Me.TxtTonZandor.TabIndex = 52
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.TxtStockPMFinos)
        Me.GroupBox8.Controls.Add(Me.TxtStockZCGruesos)
        Me.GroupBox8.Controls.Add(Me.TxtStockZCFinos)
        Me.GroupBox8.Controls.Add(Me.TxtTonHumedasZC)
        Me.GroupBox8.Controls.Add(Me.TxtTonhumedasPM)
        Me.GroupBox8.Controls.Add(Me.Label59)
        Me.GroupBox8.Controls.Add(Me.Label58)
        Me.GroupBox8.Controls.Add(Me.Label60)
        Me.GroupBox8.Controls.Add(Me.Label61)
        Me.GroupBox8.Controls.Add(Me.Label57)
        Me.GroupBox8.Controls.Add(Me.Label56)
        Me.GroupBox8.Controls.Add(Me.Label55)
        Me.GroupBox8.Controls.Add(Me.Label54)
        Me.GroupBox8.Controls.Add(Me.Label53)
        Me.GroupBox8.Controls.Add(Me.Label52)
        Me.GroupBox8.Location = New System.Drawing.Point(652, 30)
        Me.GroupBox8.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox8.Size = New System.Drawing.Size(599, 151)
        Me.GroupBox8.TabIndex = 1
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Inventario Mineral:"
        '
        'TxtStockPMFinos
        '
        Me.TxtStockPMFinos.Location = New System.Drawing.Point(483, 110)
        Me.TxtStockPMFinos.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtStockPMFinos.Name = "TxtStockPMFinos"
        Me.TxtStockPMFinos.Size = New System.Drawing.Size(92, 22)
        Me.TxtStockPMFinos.TabIndex = 51
        '
        'TxtStockZCGruesos
        '
        Me.TxtStockZCGruesos.Location = New System.Drawing.Point(253, 110)
        Me.TxtStockZCGruesos.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtStockZCGruesos.Name = "TxtStockZCGruesos"
        Me.TxtStockZCGruesos.Size = New System.Drawing.Size(92, 22)
        Me.TxtStockZCGruesos.TabIndex = 49
        '
        'TxtStockZCFinos
        '
        Me.TxtStockZCFinos.Location = New System.Drawing.Point(368, 110)
        Me.TxtStockZCFinos.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtStockZCFinos.Name = "TxtStockZCFinos"
        Me.TxtStockZCFinos.Size = New System.Drawing.Size(92, 22)
        Me.TxtStockZCFinos.TabIndex = 50
        '
        'TxtTonHumedasZC
        '
        Me.TxtTonHumedasZC.Location = New System.Drawing.Point(23, 110)
        Me.TxtTonHumedasZC.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtTonHumedasZC.Name = "TxtTonHumedasZC"
        Me.TxtTonHumedasZC.Size = New System.Drawing.Size(92, 22)
        Me.TxtTonHumedasZC.TabIndex = 47
        '
        'TxtTonhumedasPM
        '
        Me.TxtTonhumedasPM.Location = New System.Drawing.Point(135, 110)
        Me.TxtTonhumedasPM.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtTonhumedasPM.Name = "TxtTonhumedasPM"
        Me.TxtTonhumedasPM.Size = New System.Drawing.Size(92, 22)
        Me.TxtTonhumedasPM.TabIndex = 48
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.BackColor = System.Drawing.Color.LightGray
        Me.Label59.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label59.Location = New System.Drawing.Point(491, 69)
        Me.Label59.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(65, 17)
        Me.Label59.TabIndex = 61
        Me.Label59.Text = "Mineras"
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.BackColor = System.Drawing.Color.LightGray
        Me.Label58.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label58.Location = New System.Drawing.Point(325, 68)
        Me.Label58.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(60, 17)
        Me.Label58.TabIndex = 60
        Me.Label58.Text = "Zandor"
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.Label60.Location = New System.Drawing.Point(251, 87)
        Me.Label60.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(105, 17)
        Me.Label60.TabIndex = 59
        Me.Label60.Text = "Tolva Gruesos:"
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.Label61.Location = New System.Drawing.Point(364, 87)
        Me.Label61.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(85, 17)
        Me.Label61.TabIndex = 58
        Me.Label61.Text = "Tolva Finos:"
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label57.Location = New System.Drawing.Point(331, 37)
        Me.Label57.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(154, 20)
        Me.Label57.TabIndex = 57
        Me.Label57.Text = "Toneladas Stock:"
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.Label56.Location = New System.Drawing.Point(52, 90)
        Me.Label56.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(33, 17)
        Me.Label56.TabIndex = 56
        Me.Label56.Text = "Ton"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.Label55.Location = New System.Drawing.Point(155, 90)
        Me.Label55.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(33, 17)
        Me.Label55.TabIndex = 55
        Me.Label55.Text = "Ton"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(47, 71)
        Me.Label54.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(54, 17)
        Me.Label54.TabIndex = 54
        Me.Label54.Text = "Zandor"
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(141, 71)
        Me.Label53.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(58, 17)
        Me.Label53.TabIndex = 53
        Me.Label53.Text = "Mineras"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.Location = New System.Drawing.Point(24, 37)
        Me.Label52.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(190, 20)
        Me.Label52.TabIndex = 52
        Me.Label52.Text = "Toneladas Recibidas:"
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.Label81)
        Me.GroupBox10.Controls.Add(Me.TxtFundicion)
        Me.GroupBox10.Location = New System.Drawing.Point(15, 206)
        Me.GroupBox10.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox10.Size = New System.Drawing.Size(587, 100)
        Me.GroupBox10.TabIndex = 2
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "Fundición:"
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.Location = New System.Drawing.Point(129, 39)
        Me.Label81.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(53, 17)
        Me.Label81.TabIndex = 64
        Me.Label81.Text = "Onzas:"
        '
        'TxtFundicion
        '
        Me.TxtFundicion.Location = New System.Drawing.Point(245, 36)
        Me.TxtFundicion.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtFundicion.Name = "TxtFundicion"
        Me.TxtFundicion.Size = New System.Drawing.Size(116, 22)
        Me.TxtFundicion.TabIndex = 63
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.TxtOperacion)
        Me.GroupBox7.Controls.Add(Me.TxtTonHora)
        Me.GroupBox7.Controls.Add(Me.TxtHoras)
        Me.GroupBox7.Controls.Add(Me.TxtMtto)
        Me.GroupBox7.Controls.Add(Me.Txtconsumo)
        Me.GroupBox7.Controls.Add(Me.Label43)
        Me.GroupBox7.Controls.Add(Me.Label42)
        Me.GroupBox7.Controls.Add(Me.Label41)
        Me.GroupBox7.Controls.Add(Me.Label40)
        Me.GroupBox7.Controls.Add(Me.Label39)
        Me.GroupBox7.Controls.Add(Me.Label38)
        Me.GroupBox7.Controls.Add(Me.Label37)
        Me.GroupBox7.Controls.Add(Me.Label36)
        Me.GroupBox7.Controls.Add(Me.Label12)
        Me.GroupBox7.Controls.Add(Me.Label11)
        Me.GroupBox7.Controls.Add(Me.Label9)
        Me.GroupBox7.Controls.Add(Me.Label1)
        Me.GroupBox7.Controls.Add(Me.Label2)
        Me.GroupBox7.Location = New System.Drawing.Point(15, 30)
        Me.GroupBox7.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox7.Size = New System.Drawing.Size(587, 151)
        Me.GroupBox7.TabIndex = 0
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Operacion:"
        '
        'TxtOperacion
        '
        Me.TxtOperacion.Location = New System.Drawing.Point(481, 110)
        Me.TxtOperacion.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtOperacion.Name = "TxtOperacion"
        Me.TxtOperacion.Size = New System.Drawing.Size(92, 22)
        Me.TxtOperacion.TabIndex = 27
        '
        'TxtTonHora
        '
        Me.TxtTonHora.Location = New System.Drawing.Point(132, 110)
        Me.TxtTonHora.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtTonHora.Name = "TxtTonHora"
        Me.TxtTonHora.Size = New System.Drawing.Size(92, 22)
        Me.TxtTonHora.TabIndex = 23
        '
        'TxtHoras
        '
        Me.TxtHoras.Location = New System.Drawing.Point(244, 110)
        Me.TxtHoras.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtHoras.Name = "TxtHoras"
        Me.TxtHoras.Size = New System.Drawing.Size(92, 22)
        Me.TxtHoras.TabIndex = 24
        '
        'TxtMtto
        '
        Me.TxtMtto.Location = New System.Drawing.Point(367, 110)
        Me.TxtMtto.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtMtto.Name = "TxtMtto"
        Me.TxtMtto.Size = New System.Drawing.Size(92, 22)
        Me.TxtMtto.TabIndex = 25
        '
        'Txtconsumo
        '
        Me.Txtconsumo.Location = New System.Drawing.Point(17, 110)
        Me.Txtconsumo.Margin = New System.Windows.Forms.Padding(4)
        Me.Txtconsumo.Name = "Txtconsumo"
        Me.Txtconsumo.Size = New System.Drawing.Size(92, 22)
        Me.Txtconsumo.TabIndex = 22
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.Location = New System.Drawing.Point(384, 37)
        Me.Label43.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(120, 20)
        Me.Label43.TabIndex = 39
        Me.Label43.Text = "Detenciones:"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.Label42.Location = New System.Drawing.Point(389, 90)
        Me.Label42.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(44, 17)
        Me.Label42.TabIndex = 38
        Me.Label42.Text = "horas"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.Label41.Location = New System.Drawing.Point(496, 90)
        Me.Label41.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(44, 17)
        Me.Label41.TabIndex = 37
        Me.Label41.Text = "horas"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(144, 37)
        Me.Label40.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(194, 20)
        Me.Label40.TabIndex = 36
        Me.Label40.Text = "Tiempo de Operación:"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(27, 37)
        Me.Label39.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(79, 20)
        Me.Label39.TabIndex = 35
        Me.Label39.Text = "Energia:"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.Label38.Location = New System.Drawing.Point(271, 90)
        Me.Label38.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(44, 17)
        Me.Label38.TabIndex = 34
        Me.Label38.Text = "horas"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.Label37.Location = New System.Drawing.Point(167, 90)
        Me.Label37.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(45, 17)
        Me.Label37.TabIndex = 33
        Me.Label37.Text = "Ton/h"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.Label36.Location = New System.Drawing.Point(41, 90)
        Me.Label36.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(36, 17)
        Me.Label36.TabIndex = 32
        Me.Label36.Text = "kWh"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(477, 71)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(74, 17)
        Me.Label12.TabIndex = 31
        Me.Label12.Text = "Operación"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(13, 71)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(67, 17)
        Me.Label11.TabIndex = 30
        Me.Label11.Text = "Consumo"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(240, 71)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(125, 17)
        Me.Label9.TabIndex = 29
        Me.Label9.Text = "Tiempo Operacion"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(363, 71)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 17)
        Me.Label1.TabIndex = 28
        Me.Label1.Text = "Mantenimiento"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(167, 71)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(29, 17)
        Me.Label2.TabIndex = 26
        Me.Label2.Text = "Dia"
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.TabPage5.Controls.Add(Me.GroupBox25)
        Me.TabPage5.Controls.Add(Me.Label69)
        Me.TabPage5.Controls.Add(Me.GroupBox13)
        Me.TabPage5.Controls.Add(Me.DgMerrilCrowe)
        Me.TabPage5.Controls.Add(Me.GroupBox12)
        Me.TabPage5.Location = New System.Drawing.Point(4, 25)
        Me.TabPage5.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TabPage5.Size = New System.Drawing.Size(1312, 593)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Merril Crowe"
        '
        'GroupBox25
        '
        Me.GroupBox25.Controls.Add(Me.Button7)
        Me.GroupBox25.Controls.Add(Me.DtFinalMerril)
        Me.GroupBox25.Controls.Add(Me.DtInicioMerril)
        Me.GroupBox25.Location = New System.Drawing.Point(29, 495)
        Me.GroupBox25.Name = "GroupBox25"
        Me.GroupBox25.Size = New System.Drawing.Size(1157, 78)
        Me.GroupBox25.TabIndex = 47
        Me.GroupBox25.TabStop = False
        Me.GroupBox25.Text = "Exportar Datos"
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(802, 13)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(77, 31)
        Me.Button7.TabIndex = 2
        Me.Button7.Text = "Exportar"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'DtFinalMerril
        '
        Me.DtFinalMerril.Location = New System.Drawing.Point(423, 22)
        Me.DtFinalMerril.Name = "DtFinalMerril"
        Me.DtFinalMerril.Size = New System.Drawing.Size(200, 22)
        Me.DtFinalMerril.TabIndex = 1
        Me.DtFinalMerril.Value = New Date(2017, 1, 1, 0, 0, 0, 0)
        '
        'DtInicioMerril
        '
        Me.DtInicioMerril.Location = New System.Drawing.Point(157, 22)
        Me.DtInicioMerril.Name = "DtInicioMerril"
        Me.DtInicioMerril.Size = New System.Drawing.Size(200, 22)
        Me.DtInicioMerril.TabIndex = 0
        Me.DtInicioMerril.Value = New Date(2017, 1, 1, 0, 0, 0, 0)
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.Font = New System.Drawing.Font("Baskerville Old Face", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label69.Location = New System.Drawing.Point(211, 32)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(435, 32)
        Me.Label69.TabIndex = 42
        Me.Label69.Text = "Lectura Flujometro - Merril Crowe"
        '
        'GroupBox13
        '
        Me.GroupBox13.Controls.Add(Me.ChkResumerril)
        Me.GroupBox13.Controls.Add(Me.LblOzMerril)
        Me.GroupBox13.Controls.Add(Me.LblTenorMerril)
        Me.GroupBox13.Controls.Add(Me.Label51)
        Me.GroupBox13.Controls.Add(Me.Label67)
        Me.GroupBox13.Controls.Add(Me.Label68)
        Me.GroupBox13.Controls.Add(Me.LbltonMerril)
        Me.GroupBox13.Location = New System.Drawing.Point(29, 390)
        Me.GroupBox13.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox13.Name = "GroupBox13"
        Me.GroupBox13.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox13.Size = New System.Drawing.Size(1157, 100)
        Me.GroupBox13.TabIndex = 41
        Me.GroupBox13.TabStop = False
        Me.GroupBox13.Text = "Resumen:"
        '
        'ChkResumerril
        '
        Me.ChkResumerril.AutoSize = True
        Me.ChkResumerril.Enabled = False
        Me.ChkResumerril.Location = New System.Drawing.Point(1004, 62)
        Me.ChkResumerril.Margin = New System.Windows.Forms.Padding(4)
        Me.ChkResumerril.Name = "ChkResumerril"
        Me.ChkResumerril.Size = New System.Drawing.Size(94, 21)
        Me.ChkResumerril.TabIndex = 61
        Me.ChkResumerril.Text = "Ver Tenor"
        Me.ChkResumerril.UseVisualStyleBackColor = True
        '
        'LblOzMerril
        '
        Me.LblOzMerril.AutoSize = True
        Me.LblOzMerril.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblOzMerril.Location = New System.Drawing.Point(812, 62)
        Me.LblOzMerril.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblOzMerril.Name = "LblOzMerril"
        Me.LblOzMerril.Size = New System.Drawing.Size(44, 26)
        Me.LblOzMerril.TabIndex = 58
        Me.LblOzMerril.Text = "----"
        '
        'LblTenorMerril
        '
        Me.LblTenorMerril.AutoSize = True
        Me.LblTenorMerril.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTenorMerril.Location = New System.Drawing.Point(451, 62)
        Me.LblTenorMerril.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblTenorMerril.Name = "LblTenorMerril"
        Me.LblTenorMerril.Size = New System.Drawing.Size(44, 26)
        Me.LblTenorMerril.TabIndex = 57
        Me.LblTenorMerril.Text = "----"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label51.Location = New System.Drawing.Point(772, 34)
        Me.Label51.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(149, 17)
        Me.Label51.TabIndex = 55
        Me.Label51.Text = "Onzas Precipitadas"
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label67.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label67.Location = New System.Drawing.Point(447, 34)
        Me.Label67.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(51, 17)
        Me.Label67.TabIndex = 54
        Me.Label67.Text = "Tenor"
        '
        'Label68
        '
        Me.Label68.AutoEllipsis = True
        Me.Label68.AutoSize = True
        Me.Label68.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label68.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label68.Location = New System.Drawing.Point(164, 34)
        Me.Label68.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(84, 17)
        Me.Label68.TabIndex = 53
        Me.Label68.Text = "Toneladas"
        '
        'LbltonMerril
        '
        Me.LbltonMerril.AutoSize = True
        Me.LbltonMerril.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LbltonMerril.Location = New System.Drawing.Point(172, 62)
        Me.LbltonMerril.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LbltonMerril.Name = "LbltonMerril"
        Me.LbltonMerril.Size = New System.Drawing.Size(44, 26)
        Me.LbltonMerril.TabIndex = 51
        Me.LbltonMerril.Text = "----"
        '
        'DgMerrilCrowe
        '
        Me.DgMerrilCrowe.AllowUserToAddRows = False
        Me.DgMerrilCrowe.AllowUserToDeleteRows = False
        Me.DgMerrilCrowe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgMerrilCrowe.Location = New System.Drawing.Point(29, 184)
        Me.DgMerrilCrowe.Margin = New System.Windows.Forms.Padding(4)
        Me.DgMerrilCrowe.Name = "DgMerrilCrowe"
        Me.DgMerrilCrowe.RowTemplate.Height = 24
        Me.DgMerrilCrowe.Size = New System.Drawing.Size(1144, 190)
        Me.DgMerrilCrowe.TabIndex = 40
        '
        'GroupBox12
        '
        Me.GroupBox12.Controls.Add(Me.CmdSaveMC)
        Me.GroupBox12.Controls.Add(Me.Label71)
        Me.GroupBox12.Controls.Add(Me.Label72)
        Me.GroupBox12.Controls.Add(Me.Label73)
        Me.GroupBox12.Controls.Add(Me.Label74)
        Me.GroupBox12.Controls.Add(Me.TxtInicioMC)
        Me.GroupBox12.Controls.Add(Me.TxTFinalMC)
        Me.GroupBox12.Controls.Add(Me.ListMCInicio)
        Me.GroupBox12.Controls.Add(Me.ListMCFinal)
        Me.GroupBox12.Location = New System.Drawing.Point(29, 66)
        Me.GroupBox12.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox12.Name = "GroupBox12"
        Me.GroupBox12.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox12.Size = New System.Drawing.Size(1144, 100)
        Me.GroupBox12.TabIndex = 0
        Me.GroupBox12.TabStop = False
        Me.GroupBox12.Text = "Lectura Merril Crowe."
        '
        'CmdSaveMC
        '
        Me.CmdSaveMC.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdSaveMC.Location = New System.Drawing.Point(787, 50)
        Me.CmdSaveMC.Margin = New System.Windows.Forms.Padding(4)
        Me.CmdSaveMC.Name = "CmdSaveMC"
        Me.CmdSaveMC.Size = New System.Drawing.Size(100, 28)
        Me.CmdSaveMC.TabIndex = 49
        Me.CmdSaveMC.Text = "Guardar"
        Me.CmdSaveMC.UseVisualStyleBackColor = True
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.Location = New System.Drawing.Point(124, 31)
        Me.Label71.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(79, 17)
        Me.Label71.TabIndex = 53
        Me.Label71.Text = "Hora Inicio:"
        '
        'Label72
        '
        Me.Label72.AutoSize = True
        Me.Label72.Location = New System.Drawing.Point(604, 30)
        Me.Label72.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(94, 17)
        Me.Label72.TabIndex = 52
        Me.Label72.Text = "Lectura Final:"
        '
        'Label73
        '
        Me.Label73.AutoSize = True
        Me.Label73.Location = New System.Drawing.Point(276, 30)
        Me.Label73.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(77, 17)
        Me.Label73.TabIndex = 51
        Me.Label73.Text = "Hora Final:"
        '
        'Label74
        '
        Me.Label74.AutoSize = True
        Me.Label74.Location = New System.Drawing.Point(467, 30)
        Me.Label74.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(99, 17)
        Me.Label74.TabIndex = 50
        Me.Label74.Text = "Lectura Inicial:"
        '
        'TxtInicioMC
        '
        Me.TxtInicioMC.Location = New System.Drawing.Point(451, 54)
        Me.TxtInicioMC.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtInicioMC.Name = "TxtInicioMC"
        Me.TxtInicioMC.Size = New System.Drawing.Size(105, 22)
        Me.TxtInicioMC.TabIndex = 47
        '
        'TxTFinalMC
        '
        Me.TxTFinalMC.Location = New System.Drawing.Point(587, 54)
        Me.TxTFinalMC.Margin = New System.Windows.Forms.Padding(4)
        Me.TxTFinalMC.Name = "TxTFinalMC"
        Me.TxTFinalMC.Size = New System.Drawing.Size(105, 22)
        Me.TxTFinalMC.TabIndex = 48
        '
        'ListMCInicio
        '
        Me.ListMCInicio.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListMCInicio.FormattingEnabled = True
        Me.ListMCInicio.ItemHeight = 20
        Me.ListMCInicio.Location = New System.Drawing.Point(104, 54)
        Me.ListMCInicio.Margin = New System.Windows.Forms.Padding(4)
        Me.ListMCInicio.Name = "ListMCInicio"
        Me.ListMCInicio.Size = New System.Drawing.Size(105, 24)
        Me.ListMCInicio.TabIndex = 45
        '
        'ListMCFinal
        '
        Me.ListMCFinal.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListMCFinal.FormattingEnabled = True
        Me.ListMCFinal.ItemHeight = 20
        Me.ListMCFinal.Location = New System.Drawing.Point(267, 54)
        Me.ListMCFinal.Margin = New System.Windows.Forms.Padding(4)
        Me.ListMCFinal.Name = "ListMCFinal"
        Me.ListMCFinal.Size = New System.Drawing.Size(105, 24)
        Me.ListMCFinal.TabIndex = 46
        '
        'TabPage6
        '
        Me.TabPage6.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.TabPage6.Controls.Add(Me.GroupBox22)
        Me.TabPage6.Controls.Add(Me.Label50)
        Me.TabPage6.Controls.Add(Me.DgHorometro)
        Me.TabPage6.Controls.Add(Me.GroupBox14)
        Me.TabPage6.Location = New System.Drawing.Point(4, 25)
        Me.TabPage6.Margin = New System.Windows.Forms.Padding(4)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(4)
        Me.TabPage6.Size = New System.Drawing.Size(1312, 593)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "Horometro Molino"
        '
        'GroupBox22
        '
        Me.GroupBox22.Controls.Add(Me.LblHorasMolienda)
        Me.GroupBox22.Controls.Add(Me.Label118)
        Me.GroupBox22.Location = New System.Drawing.Point(112, 401)
        Me.GroupBox22.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox22.Name = "GroupBox22"
        Me.GroupBox22.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox22.Size = New System.Drawing.Size(1051, 95)
        Me.GroupBox22.TabIndex = 43
        Me.GroupBox22.TabStop = False
        Me.GroupBox22.Text = "Resumen:"
        '
        'LblHorasMolienda
        '
        Me.LblHorasMolienda.AutoSize = True
        Me.LblHorasMolienda.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblHorasMolienda.Location = New System.Drawing.Point(677, 52)
        Me.LblHorasMolienda.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblHorasMolienda.Name = "LblHorasMolienda"
        Me.LblHorasMolienda.Size = New System.Drawing.Size(44, 26)
        Me.LblHorasMolienda.TabIndex = 58
        Me.LblHorasMolienda.Text = "----"
        '
        'Label118
        '
        Me.Label118.AutoSize = True
        Me.Label118.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label118.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label118.Location = New System.Drawing.Point(629, 17)
        Me.Label118.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label118.Name = "Label118"
        Me.Label118.Size = New System.Drawing.Size(154, 17)
        Me.Label118.TabIndex = 55
        Me.Label118.Text = "Horas de Operacion"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Font = New System.Drawing.Font("Baskerville Old Face", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.Location = New System.Drawing.Point(211, 20)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(566, 32)
        Me.Label50.TabIndex = 4
        Me.Label50.Text = "Lectura Horometro - Concentrador K Nelson"
        '
        'DgHorometro
        '
        Me.DgHorometro.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgHorometro.Location = New System.Drawing.Point(163, 199)
        Me.DgHorometro.Margin = New System.Windows.Forms.Padding(4)
        Me.DgHorometro.Name = "DgHorometro"
        Me.DgHorometro.Size = New System.Drawing.Size(796, 185)
        Me.DgHorometro.TabIndex = 1
        '
        'GroupBox14
        '
        Me.GroupBox14.Controls.Add(Me.Label102)
        Me.GroupBox14.Controls.Add(Me.Label101)
        Me.GroupBox14.Controls.Add(Me.Label100)
        Me.GroupBox14.Controls.Add(Me.Button1)
        Me.GroupBox14.Controls.Add(Me.Cmbturno)
        Me.GroupBox14.Controls.Add(Me.TxtLfinalHorometro)
        Me.GroupBox14.Controls.Add(Me.TxtLinicialHorometro)
        Me.GroupBox14.Location = New System.Drawing.Point(125, 77)
        Me.GroupBox14.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox14.Name = "GroupBox14"
        Me.GroupBox14.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox14.Size = New System.Drawing.Size(980, 103)
        Me.GroupBox14.TabIndex = 0
        Me.GroupBox14.TabStop = False
        Me.GroupBox14.Text = "Lectura Horometro"
        '
        'Label102
        '
        Me.Label102.AutoSize = True
        Me.Label102.Location = New System.Drawing.Point(408, 28)
        Me.Label102.Name = "Label102"
        Me.Label102.Size = New System.Drawing.Size(50, 17)
        Me.Label102.TabIndex = 10
        Me.Label102.Text = "Turno:"
        '
        'Label101
        '
        Me.Label101.AutoSize = True
        Me.Label101.Location = New System.Drawing.Point(208, 28)
        Me.Label101.Name = "Label101"
        Me.Label101.Size = New System.Drawing.Size(94, 17)
        Me.Label101.TabIndex = 9
        Me.Label101.Text = "Lectura Final:"
        '
        'Label100
        '
        Me.Label100.AutoSize = True
        Me.Label100.Location = New System.Drawing.Point(35, 28)
        Me.Label100.Name = "Label100"
        Me.Label100.Size = New System.Drawing.Size(99, 17)
        Me.Label100.TabIndex = 8
        Me.Label100.Text = "Lectura Inicial:"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(660, 46)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(100, 28)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "Guardar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Cmbturno
        '
        Me.Cmbturno.FormattingEnabled = True
        Me.Cmbturno.Items.AddRange(New Object() {"Turno1", "Turno2", "Turno3"})
        Me.Cmbturno.Location = New System.Drawing.Point(411, 49)
        Me.Cmbturno.Margin = New System.Windows.Forms.Padding(4)
        Me.Cmbturno.Name = "Cmbturno"
        Me.Cmbturno.Size = New System.Drawing.Size(160, 24)
        Me.Cmbturno.TabIndex = 2
        '
        'TxtLfinalHorometro
        '
        Me.TxtLfinalHorometro.Location = New System.Drawing.Point(211, 49)
        Me.TxtLfinalHorometro.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtLfinalHorometro.Name = "TxtLfinalHorometro"
        Me.TxtLfinalHorometro.Size = New System.Drawing.Size(132, 22)
        Me.TxtLfinalHorometro.TabIndex = 1
        '
        'TxtLinicialHorometro
        '
        Me.TxtLinicialHorometro.Location = New System.Drawing.Point(39, 49)
        Me.TxtLinicialHorometro.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtLinicialHorometro.Name = "TxtLinicialHorometro"
        Me.TxtLinicialHorometro.Size = New System.Drawing.Size(132, 22)
        Me.TxtLinicialHorometro.TabIndex = 0
        '
        'TabPage7
        '
        Me.TabPage7.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.TabPage7.Controls.Add(Me.GroupBox23)
        Me.TabPage7.Controls.Add(Me.Label48)
        Me.TabPage7.Controls.Add(Me.DgHorometroKnelson)
        Me.TabPage7.Controls.Add(Me.GroupBox15)
        Me.TabPage7.Location = New System.Drawing.Point(4, 25)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(1312, 593)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "Concentrador Knelson"
        '
        'GroupBox23
        '
        Me.GroupBox23.Controls.Add(Me.LblHorasConcentrador)
        Me.GroupBox23.Controls.Add(Me.Label114)
        Me.GroupBox23.Location = New System.Drawing.Point(51, 362)
        Me.GroupBox23.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox23.Name = "GroupBox23"
        Me.GroupBox23.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox23.Size = New System.Drawing.Size(980, 95)
        Me.GroupBox23.TabIndex = 44
        Me.GroupBox23.TabStop = False
        Me.GroupBox23.Text = "Resumen:"
        '
        'LblHorasConcentrador
        '
        Me.LblHorasConcentrador.AutoSize = True
        Me.LblHorasConcentrador.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblHorasConcentrador.Location = New System.Drawing.Point(677, 52)
        Me.LblHorasConcentrador.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblHorasConcentrador.Name = "LblHorasConcentrador"
        Me.LblHorasConcentrador.Size = New System.Drawing.Size(44, 26)
        Me.LblHorasConcentrador.TabIndex = 58
        Me.LblHorasConcentrador.Text = "----"
        '
        'Label114
        '
        Me.Label114.AutoSize = True
        Me.Label114.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label114.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label114.Location = New System.Drawing.Point(629, 17)
        Me.Label114.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label114.Name = "Label114"
        Me.Label114.Size = New System.Drawing.Size(154, 17)
        Me.Label114.TabIndex = 55
        Me.Label114.Text = "Horas de Operacion"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("Baskerville Old Face", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.Location = New System.Drawing.Point(211, 24)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(566, 32)
        Me.Label48.TabIndex = 3
        Me.Label48.Text = "Lectura Horometro - Concentrador K Nelson"
        '
        'DgHorometroKnelson
        '
        Me.DgHorometroKnelson.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgHorometroKnelson.Location = New System.Drawing.Point(90, 189)
        Me.DgHorometroKnelson.Name = "DgHorometroKnelson"
        Me.DgHorometroKnelson.RowTemplate.Height = 24
        Me.DgHorometroKnelson.Size = New System.Drawing.Size(832, 150)
        Me.DgHorometroKnelson.TabIndex = 2
        '
        'GroupBox15
        '
        Me.GroupBox15.Controls.Add(Me.Label99)
        Me.GroupBox15.Controls.Add(Me.Label98)
        Me.GroupBox15.Controls.Add(Me.Button2)
        Me.GroupBox15.Controls.Add(Me.Label97)
        Me.GroupBox15.Controls.Add(Me.CmbKNelsonTurn)
        Me.GroupBox15.Controls.Add(Me.TxtHKNelsonF)
        Me.GroupBox15.Controls.Add(Me.TxtHKNelsonI)
        Me.GroupBox15.Location = New System.Drawing.Point(51, 79)
        Me.GroupBox15.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox15.Name = "GroupBox15"
        Me.GroupBox15.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox15.Size = New System.Drawing.Size(980, 103)
        Me.GroupBox15.TabIndex = 1
        Me.GroupBox15.TabStop = False
        Me.GroupBox15.Text = "Concentrador K Nelson"
        '
        'Label99
        '
        Me.Label99.AutoSize = True
        Me.Label99.Location = New System.Drawing.Point(408, 28)
        Me.Label99.Name = "Label99"
        Me.Label99.Size = New System.Drawing.Size(50, 17)
        Me.Label99.TabIndex = 9
        Me.Label99.Text = "Turno:"
        '
        'Label98
        '
        Me.Label98.AutoSize = True
        Me.Label98.Location = New System.Drawing.Point(208, 28)
        Me.Label98.Name = "Label98"
        Me.Label98.Size = New System.Drawing.Size(94, 17)
        Me.Label98.TabIndex = 8
        Me.Label98.Text = "Lectura Final:"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(660, 46)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(100, 28)
        Me.Button2.TabIndex = 3
        Me.Button2.Text = "Guardar"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label97
        '
        Me.Label97.AutoSize = True
        Me.Label97.Location = New System.Drawing.Point(36, 28)
        Me.Label97.Name = "Label97"
        Me.Label97.Size = New System.Drawing.Size(99, 17)
        Me.Label97.TabIndex = 7
        Me.Label97.Text = "Lectura Inicial:"
        '
        'CmbKNelsonTurn
        '
        Me.CmbKNelsonTurn.FormattingEnabled = True
        Me.CmbKNelsonTurn.Items.AddRange(New Object() {"Turno1", "Turno2", "Turno3"})
        Me.CmbKNelsonTurn.Location = New System.Drawing.Point(411, 49)
        Me.CmbKNelsonTurn.Margin = New System.Windows.Forms.Padding(4)
        Me.CmbKNelsonTurn.Name = "CmbKNelsonTurn"
        Me.CmbKNelsonTurn.Size = New System.Drawing.Size(160, 24)
        Me.CmbKNelsonTurn.TabIndex = 2
        '
        'TxtHKNelsonF
        '
        Me.TxtHKNelsonF.Location = New System.Drawing.Point(211, 49)
        Me.TxtHKNelsonF.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtHKNelsonF.Name = "TxtHKNelsonF"
        Me.TxtHKNelsonF.Size = New System.Drawing.Size(132, 22)
        Me.TxtHKNelsonF.TabIndex = 1
        '
        'TxtHKNelsonI
        '
        Me.TxtHKNelsonI.Location = New System.Drawing.Point(39, 49)
        Me.TxtHKNelsonI.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtHKNelsonI.Name = "TxtHKNelsonI"
        Me.TxtHKNelsonI.Size = New System.Drawing.Size(132, 22)
        Me.TxtHKNelsonI.TabIndex = 0
        '
        'TabPage8
        '
        Me.TabPage8.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.TabPage8.Controls.Add(Me.GroupBox18)
        Me.TabPage8.Controls.Add(Me.GroupBox17)
        Me.TabPage8.Controls.Add(Me.DgFlujoE5)
        Me.TabPage8.Controls.Add(Me.Label32)
        Me.TabPage8.Controls.Add(Me.GroupBox16)
        Me.TabPage8.Location = New System.Drawing.Point(4, 25)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage8.Size = New System.Drawing.Size(1312, 593)
        Me.TabPage8.TabIndex = 7
        Me.TabPage8.Text = "Flujometro Cesp5"
        '
        'GroupBox18
        '
        Me.GroupBox18.Controls.Add(Me.CmdExportarFlowsE5)
        Me.GroupBox18.Controls.Add(Me.DtFinalE5)
        Me.GroupBox18.Controls.Add(Me.DtInicioE5)
        Me.GroupBox18.Location = New System.Drawing.Point(78, 494)
        Me.GroupBox18.Name = "GroupBox18"
        Me.GroupBox18.Size = New System.Drawing.Size(1051, 78)
        Me.GroupBox18.TabIndex = 43
        Me.GroupBox18.TabStop = False
        Me.GroupBox18.Text = "Exportar Datos"
        '
        'CmdExportarFlowsE5
        '
        Me.CmdExportarFlowsE5.Location = New System.Drawing.Point(739, 22)
        Me.CmdExportarFlowsE5.Name = "CmdExportarFlowsE5"
        Me.CmdExportarFlowsE5.Size = New System.Drawing.Size(77, 31)
        Me.CmdExportarFlowsE5.TabIndex = 2
        Me.CmdExportarFlowsE5.Text = "Exportar"
        Me.CmdExportarFlowsE5.UseVisualStyleBackColor = True
        '
        'DtFinalE5
        '
        Me.DtFinalE5.Location = New System.Drawing.Point(423, 22)
        Me.DtFinalE5.Name = "DtFinalE5"
        Me.DtFinalE5.Size = New System.Drawing.Size(200, 22)
        Me.DtFinalE5.TabIndex = 1
        Me.DtFinalE5.Value = New Date(2017, 1, 1, 0, 0, 0, 0)
        '
        'DtInicioE5
        '
        Me.DtInicioE5.Location = New System.Drawing.Point(157, 22)
        Me.DtInicioE5.Name = "DtInicioE5"
        Me.DtInicioE5.Size = New System.Drawing.Size(200, 22)
        Me.DtInicioE5.TabIndex = 0
        Me.DtInicioE5.Value = New Date(2017, 1, 1, 0, 0, 0, 0)
        '
        'GroupBox17
        '
        Me.GroupBox17.Controls.Add(Me.LblHorasE5)
        Me.GroupBox17.Controls.Add(Me.LblDensidadE5)
        Me.GroupBox17.Controls.Add(Me.Label106)
        Me.GroupBox17.Controls.Add(Me.Label107)
        Me.GroupBox17.Controls.Add(Me.Label108)
        Me.GroupBox17.Controls.Add(Me.LblTonsE5)
        Me.GroupBox17.Location = New System.Drawing.Point(78, 377)
        Me.GroupBox17.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox17.Name = "GroupBox17"
        Me.GroupBox17.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox17.Size = New System.Drawing.Size(1051, 95)
        Me.GroupBox17.TabIndex = 42
        Me.GroupBox17.TabStop = False
        Me.GroupBox17.Text = "Resumen:"
        '
        'LblHorasE5
        '
        Me.LblHorasE5.AutoSize = True
        Me.LblHorasE5.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblHorasE5.Location = New System.Drawing.Point(734, 52)
        Me.LblHorasE5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblHorasE5.Name = "LblHorasE5"
        Me.LblHorasE5.Size = New System.Drawing.Size(44, 26)
        Me.LblHorasE5.TabIndex = 58
        Me.LblHorasE5.Text = "----"
        '
        'LblDensidadE5
        '
        Me.LblDensidadE5.AutoSize = True
        Me.LblDensidadE5.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblDensidadE5.Location = New System.Drawing.Point(424, 62)
        Me.LblDensidadE5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblDensidadE5.Name = "LblDensidadE5"
        Me.LblDensidadE5.Size = New System.Drawing.Size(44, 26)
        Me.LblDensidadE5.TabIndex = 57
        Me.LblDensidadE5.Text = "----"
        '
        'Label106
        '
        Me.Label106.AutoSize = True
        Me.Label106.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label106.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label106.Location = New System.Drawing.Point(694, 24)
        Me.Label106.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label106.Name = "Label106"
        Me.Label106.Size = New System.Drawing.Size(154, 17)
        Me.Label106.TabIndex = 55
        Me.Label106.Text = "Horas de Operacion"
        '
        'Label107
        '
        Me.Label107.AutoSize = True
        Me.Label107.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label107.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label107.Location = New System.Drawing.Point(420, 34)
        Me.Label107.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label107.Name = "Label107"
        Me.Label107.Size = New System.Drawing.Size(76, 17)
        Me.Label107.TabIndex = 54
        Me.Label107.Text = "Densidad"
        '
        'Label108
        '
        Me.Label108.AutoEllipsis = True
        Me.Label108.AutoSize = True
        Me.Label108.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label108.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label108.Location = New System.Drawing.Point(164, 34)
        Me.Label108.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label108.Name = "Label108"
        Me.Label108.Size = New System.Drawing.Size(84, 17)
        Me.Label108.TabIndex = 53
        Me.Label108.Text = "Toneladas"
        '
        'LblTonsE5
        '
        Me.LblTonsE5.AutoSize = True
        Me.LblTonsE5.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTonsE5.Location = New System.Drawing.Point(172, 62)
        Me.LblTonsE5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblTonsE5.Name = "LblTonsE5"
        Me.LblTonsE5.Size = New System.Drawing.Size(44, 26)
        Me.LblTonsE5.TabIndex = 51
        Me.LblTonsE5.Text = "----"
        '
        'DgFlujoE5
        '
        Me.DgFlujoE5.AllowUserToAddRows = False
        Me.DgFlujoE5.AllowUserToDeleteRows = False
        Me.DgFlujoE5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgFlujoE5.Location = New System.Drawing.Point(96, 205)
        Me.DgFlujoE5.Name = "DgFlujoE5"
        Me.DgFlujoE5.RowTemplate.Height = 24
        Me.DgFlujoE5.Size = New System.Drawing.Size(1009, 150)
        Me.DgFlujoE5.TabIndex = 3
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Baskerville Old Face", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(211, 26)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(497, 32)
        Me.Label32.TabIndex = 2
        Me.Label32.Text = "Lectura Flujometro - Bomba Peristaltica"
        '
        'GroupBox16
        '
        Me.GroupBox16.Controls.Add(Me.TxtHVertCep5)
        Me.GroupBox16.Controls.Add(Me.Label113)
        Me.GroupBox16.Controls.Add(Me.TxtHorasOperacione5)
        Me.GroupBox16.Controls.Add(Me.Label103)
        Me.GroupBox16.Controls.Add(Me.Label94)
        Me.GroupBox16.Controls.Add(Me.TxtDensidadE5)
        Me.GroupBox16.Controls.Add(Me.Label80)
        Me.GroupBox16.Controls.Add(Me.Label90)
        Me.GroupBox16.Controls.Add(Me.Button3)
        Me.GroupBox16.Controls.Add(Me.Label87)
        Me.GroupBox16.Controls.Add(Me.CmbTurnoE5)
        Me.GroupBox16.Controls.Add(Me.TxtFinalE5)
        Me.GroupBox16.Controls.Add(Me.TxtInicioE5)
        Me.GroupBox16.Location = New System.Drawing.Point(57, 62)
        Me.GroupBox16.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox16.Name = "GroupBox16"
        Me.GroupBox16.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox16.Size = New System.Drawing.Size(1217, 103)
        Me.GroupBox16.TabIndex = 1
        Me.GroupBox16.TabStop = False
        Me.GroupBox16.Text = "Lectura Flujometro Bomba Peristaltica "
        '
        'TxtHorasOperacione5
        '
        Me.TxtHorasOperacione5.Location = New System.Drawing.Point(548, 50)
        Me.TxtHorasOperacione5.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtHorasOperacione5.Name = "TxtHorasOperacione5"
        Me.TxtHorasOperacione5.Size = New System.Drawing.Size(132, 22)
        Me.TxtHorasOperacione5.TabIndex = 3
        '
        'Label103
        '
        Me.Label103.AutoSize = True
        Me.Label103.Location = New System.Drawing.Point(545, 29)
        Me.Label103.Name = "Label103"
        Me.Label103.Size = New System.Drawing.Size(120, 17)
        Me.Label103.TabIndex = 10
        Me.Label103.Text = "Horas Operacion:"
        '
        'Label94
        '
        Me.Label94.AutoSize = True
        Me.Label94.Location = New System.Drawing.Point(867, 29)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(50, 17)
        Me.Label94.TabIndex = 8
        Me.Label94.Text = "Turno:"
        '
        'TxtDensidadE5
        '
        Me.TxtDensidadE5.Location = New System.Drawing.Point(375, 49)
        Me.TxtDensidadE5.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtDensidadE5.Name = "TxtDensidadE5"
        Me.TxtDensidadE5.Size = New System.Drawing.Size(132, 22)
        Me.TxtDensidadE5.TabIndex = 2
        '
        'Label80
        '
        Me.Label80.AutoSize = True
        Me.Label80.Location = New System.Drawing.Point(372, 28)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(72, 17)
        Me.Label80.TabIndex = 5
        Me.Label80.Text = "Densidad:"
        '
        'Label90
        '
        Me.Label90.AutoSize = True
        Me.Label90.Location = New System.Drawing.Point(208, 28)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(94, 17)
        Me.Label90.TabIndex = 7
        Me.Label90.Text = "Lectura Final:"
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(1048, 46)
        Me.Button3.Margin = New System.Windows.Forms.Padding(4)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(100, 28)
        Me.Button3.TabIndex = 3
        Me.Button3.Text = "Guardar"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label87
        '
        Me.Label87.AutoSize = True
        Me.Label87.Location = New System.Drawing.Point(36, 28)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(99, 17)
        Me.Label87.TabIndex = 6
        Me.Label87.Text = "Lectura Inicial:"
        '
        'CmbTurnoE5
        '
        Me.CmbTurnoE5.FormattingEnabled = True
        Me.CmbTurnoE5.Items.AddRange(New Object() {"Turno1", "Turno2", "Turno3"})
        Me.CmbTurnoE5.Location = New System.Drawing.Point(870, 50)
        Me.CmbTurnoE5.Margin = New System.Windows.Forms.Padding(4)
        Me.CmbTurnoE5.Name = "CmbTurnoE5"
        Me.CmbTurnoE5.Size = New System.Drawing.Size(160, 24)
        Me.CmbTurnoE5.TabIndex = 5
        '
        'TxtFinalE5
        '
        Me.TxtFinalE5.Location = New System.Drawing.Point(211, 49)
        Me.TxtFinalE5.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtFinalE5.Name = "TxtFinalE5"
        Me.TxtFinalE5.Size = New System.Drawing.Size(132, 22)
        Me.TxtFinalE5.TabIndex = 1
        '
        'TxtInicioE5
        '
        Me.TxtInicioE5.Location = New System.Drawing.Point(39, 49)
        Me.TxtInicioE5.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtInicioE5.Name = "TxtInicioE5"
        Me.TxtInicioE5.Size = New System.Drawing.Size(132, 22)
        Me.TxtInicioE5.TabIndex = 0
        '
        'TabPage9
        '
        Me.TabPage9.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.TabPage9.Controls.Add(Me.GroupBox20)
        Me.TabPage9.Controls.Add(Me.GroupBox21)
        Me.TabPage9.Controls.Add(Me.DgColasFlotacion)
        Me.TabPage9.Controls.Add(Me.Label104)
        Me.TabPage9.Controls.Add(Me.GroupBox19)
        Me.TabPage9.Location = New System.Drawing.Point(4, 25)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage9.Size = New System.Drawing.Size(1312, 593)
        Me.TabPage9.TabIndex = 8
        Me.TabPage9.Text = "Colas Flotacion"
        '
        'GroupBox20
        '
        Me.GroupBox20.Controls.Add(Me.Button5)
        Me.GroupBox20.Controls.Add(Me.DtFinalFl)
        Me.GroupBox20.Controls.Add(Me.DtInicioFl)
        Me.GroupBox20.Location = New System.Drawing.Point(54, 509)
        Me.GroupBox20.Name = "GroupBox20"
        Me.GroupBox20.Size = New System.Drawing.Size(1051, 78)
        Me.GroupBox20.TabIndex = 45
        Me.GroupBox20.TabStop = False
        Me.GroupBox20.Text = "Exportar Datos"
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(739, 22)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(77, 31)
        Me.Button5.TabIndex = 2
        Me.Button5.Text = "Exportar"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'DtFinalFl
        '
        Me.DtFinalFl.Location = New System.Drawing.Point(423, 22)
        Me.DtFinalFl.Name = "DtFinalFl"
        Me.DtFinalFl.Size = New System.Drawing.Size(200, 22)
        Me.DtFinalFl.TabIndex = 1
        Me.DtFinalFl.Value = New Date(2017, 1, 1, 0, 0, 0, 0)
        '
        'DtInicioFl
        '
        Me.DtInicioFl.Location = New System.Drawing.Point(157, 22)
        Me.DtInicioFl.Name = "DtInicioFl"
        Me.DtInicioFl.Size = New System.Drawing.Size(200, 22)
        Me.DtInicioFl.TabIndex = 0
        Me.DtInicioFl.Value = New Date(2017, 1, 1, 0, 0, 0, 0)
        '
        'GroupBox21
        '
        Me.GroupBox21.Controls.Add(Me.LblHorasFlotacion)
        Me.GroupBox21.Controls.Add(Me.LbldensidadFlotacion)
        Me.GroupBox21.Controls.Add(Me.Label115)
        Me.GroupBox21.Controls.Add(Me.Label116)
        Me.GroupBox21.Controls.Add(Me.Label117)
        Me.GroupBox21.Controls.Add(Me.LbltonsFlotacion)
        Me.GroupBox21.Location = New System.Drawing.Point(54, 389)
        Me.GroupBox21.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox21.Name = "GroupBox21"
        Me.GroupBox21.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox21.Size = New System.Drawing.Size(1051, 95)
        Me.GroupBox21.TabIndex = 44
        Me.GroupBox21.TabStop = False
        Me.GroupBox21.Text = "Resumen:"
        '
        'LblHorasFlotacion
        '
        Me.LblHorasFlotacion.AutoSize = True
        Me.LblHorasFlotacion.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblHorasFlotacion.Location = New System.Drawing.Point(734, 52)
        Me.LblHorasFlotacion.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblHorasFlotacion.Name = "LblHorasFlotacion"
        Me.LblHorasFlotacion.Size = New System.Drawing.Size(44, 26)
        Me.LblHorasFlotacion.TabIndex = 58
        Me.LblHorasFlotacion.Text = "----"
        '
        'LbldensidadFlotacion
        '
        Me.LbldensidadFlotacion.AutoSize = True
        Me.LbldensidadFlotacion.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LbldensidadFlotacion.Location = New System.Drawing.Point(424, 62)
        Me.LbldensidadFlotacion.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LbldensidadFlotacion.Name = "LbldensidadFlotacion"
        Me.LbldensidadFlotacion.Size = New System.Drawing.Size(44, 26)
        Me.LbldensidadFlotacion.TabIndex = 57
        Me.LbldensidadFlotacion.Text = "----"
        '
        'Label115
        '
        Me.Label115.AutoSize = True
        Me.Label115.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label115.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label115.Location = New System.Drawing.Point(694, 24)
        Me.Label115.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label115.Name = "Label115"
        Me.Label115.Size = New System.Drawing.Size(154, 17)
        Me.Label115.TabIndex = 55
        Me.Label115.Text = "Horas de Operacion"
        '
        'Label116
        '
        Me.Label116.AutoSize = True
        Me.Label116.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label116.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label116.Location = New System.Drawing.Point(420, 34)
        Me.Label116.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label116.Name = "Label116"
        Me.Label116.Size = New System.Drawing.Size(76, 17)
        Me.Label116.TabIndex = 54
        Me.Label116.Text = "Densidad"
        '
        'Label117
        '
        Me.Label117.AutoEllipsis = True
        Me.Label117.AutoSize = True
        Me.Label117.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label117.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label117.Location = New System.Drawing.Point(164, 34)
        Me.Label117.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label117.Name = "Label117"
        Me.Label117.Size = New System.Drawing.Size(84, 17)
        Me.Label117.TabIndex = 53
        Me.Label117.Text = "Toneladas"
        '
        'LbltonsFlotacion
        '
        Me.LbltonsFlotacion.AutoSize = True
        Me.LbltonsFlotacion.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LbltonsFlotacion.Location = New System.Drawing.Point(172, 62)
        Me.LbltonsFlotacion.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LbltonsFlotacion.Name = "LbltonsFlotacion"
        Me.LbltonsFlotacion.Size = New System.Drawing.Size(44, 26)
        Me.LbltonsFlotacion.TabIndex = 51
        Me.LbltonsFlotacion.Text = "----"
        '
        'DgColasFlotacion
        '
        Me.DgColasFlotacion.AllowUserToAddRows = False
        Me.DgColasFlotacion.AllowUserToDeleteRows = False
        Me.DgColasFlotacion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgColasFlotacion.Location = New System.Drawing.Point(96, 205)
        Me.DgColasFlotacion.Name = "DgColasFlotacion"
        Me.DgColasFlotacion.RowTemplate.Height = 24
        Me.DgColasFlotacion.Size = New System.Drawing.Size(1009, 150)
        Me.DgColasFlotacion.TabIndex = 6
        '
        'Label104
        '
        Me.Label104.AutoSize = True
        Me.Label104.Font = New System.Drawing.Font("Baskerville Old Face", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label104.Location = New System.Drawing.Point(211, 26)
        Me.Label104.Name = "Label104"
        Me.Label104.Size = New System.Drawing.Size(447, 32)
        Me.Label104.TabIndex = 5
        Me.Label104.Text = "Lectura Flujometro - Cola Flotacion"
        '
        'GroupBox19
        '
        Me.GroupBox19.Controls.Add(Me.TxtHVertimientoFl)
        Me.GroupBox19.Controls.Add(Me.Label119)
        Me.GroupBox19.Controls.Add(Me.TxtHorasFl)
        Me.GroupBox19.Controls.Add(Me.Label105)
        Me.GroupBox19.Controls.Add(Me.Label109)
        Me.GroupBox19.Controls.Add(Me.TxtDensidadFl)
        Me.GroupBox19.Controls.Add(Me.Label110)
        Me.GroupBox19.Controls.Add(Me.Label111)
        Me.GroupBox19.Controls.Add(Me.Button4)
        Me.GroupBox19.Controls.Add(Me.Label112)
        Me.GroupBox19.Controls.Add(Me.CmbTurnoFl)
        Me.GroupBox19.Controls.Add(Me.TxtFinalFl)
        Me.GroupBox19.Controls.Add(Me.TxtInicioFl)
        Me.GroupBox19.Location = New System.Drawing.Point(57, 62)
        Me.GroupBox19.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox19.Name = "GroupBox19"
        Me.GroupBox19.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox19.Size = New System.Drawing.Size(1179, 103)
        Me.GroupBox19.TabIndex = 4
        Me.GroupBox19.TabStop = False
        Me.GroupBox19.Text = "Lectura Flujometro Cola Flotacion  "
        '
        'TxtHorasFl
        '
        Me.TxtHorasFl.Location = New System.Drawing.Point(548, 50)
        Me.TxtHorasFl.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtHorasFl.Name = "TxtHorasFl"
        Me.TxtHorasFl.Size = New System.Drawing.Size(132, 22)
        Me.TxtHorasFl.TabIndex = 3
        '
        'Label105
        '
        Me.Label105.AutoSize = True
        Me.Label105.Location = New System.Drawing.Point(545, 29)
        Me.Label105.Name = "Label105"
        Me.Label105.Size = New System.Drawing.Size(120, 17)
        Me.Label105.TabIndex = 10
        Me.Label105.Text = "Horas Operacion:"
        '
        'Label109
        '
        Me.Label109.AutoSize = True
        Me.Label109.Location = New System.Drawing.Point(854, 29)
        Me.Label109.Name = "Label109"
        Me.Label109.Size = New System.Drawing.Size(50, 17)
        Me.Label109.TabIndex = 8
        Me.Label109.Text = "Turno:"
        '
        'TxtDensidadFl
        '
        Me.TxtDensidadFl.Location = New System.Drawing.Point(375, 49)
        Me.TxtDensidadFl.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtDensidadFl.Name = "TxtDensidadFl"
        Me.TxtDensidadFl.Size = New System.Drawing.Size(132, 22)
        Me.TxtDensidadFl.TabIndex = 2
        '
        'Label110
        '
        Me.Label110.AutoSize = True
        Me.Label110.Location = New System.Drawing.Point(372, 28)
        Me.Label110.Name = "Label110"
        Me.Label110.Size = New System.Drawing.Size(72, 17)
        Me.Label110.TabIndex = 5
        Me.Label110.Text = "Densidad:"
        '
        'Label111
        '
        Me.Label111.AutoSize = True
        Me.Label111.Location = New System.Drawing.Point(208, 28)
        Me.Label111.Name = "Label111"
        Me.Label111.Size = New System.Drawing.Size(94, 17)
        Me.Label111.TabIndex = 7
        Me.Label111.Text = "Lectura Final:"
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(1035, 46)
        Me.Button4.Margin = New System.Windows.Forms.Padding(4)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(100, 28)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "Guardar"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Label112
        '
        Me.Label112.AutoSize = True
        Me.Label112.Location = New System.Drawing.Point(36, 28)
        Me.Label112.Name = "Label112"
        Me.Label112.Size = New System.Drawing.Size(99, 17)
        Me.Label112.TabIndex = 6
        Me.Label112.Text = "Lectura Inicial:"
        '
        'CmbTurnoFl
        '
        Me.CmbTurnoFl.FormattingEnabled = True
        Me.CmbTurnoFl.Items.AddRange(New Object() {"Turno1", "Turno2", "Turno3"})
        Me.CmbTurnoFl.Location = New System.Drawing.Point(857, 50)
        Me.CmbTurnoFl.Margin = New System.Windows.Forms.Padding(4)
        Me.CmbTurnoFl.Name = "CmbTurnoFl"
        Me.CmbTurnoFl.Size = New System.Drawing.Size(160, 24)
        Me.CmbTurnoFl.TabIndex = 5
        '
        'TxtFinalFl
        '
        Me.TxtFinalFl.Location = New System.Drawing.Point(211, 49)
        Me.TxtFinalFl.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtFinalFl.Name = "TxtFinalFl"
        Me.TxtFinalFl.Size = New System.Drawing.Size(132, 22)
        Me.TxtFinalFl.TabIndex = 1
        '
        'TxtInicioFl
        '
        Me.TxtInicioFl.Location = New System.Drawing.Point(39, 49)
        Me.TxtInicioFl.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtInicioFl.Name = "TxtInicioFl"
        Me.TxtInicioFl.Size = New System.Drawing.Size(132, 22)
        Me.TxtInicioFl.TabIndex = 0
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Z_Lab.My.Resources.Resources.LogoGranColombiaGoldSmall
        Me.PictureBox1.Location = New System.Drawing.Point(868, 60)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(276, 62)
        Me.PictureBox1.TabIndex = 20
        Me.PictureBox1.TabStop = False
        '
        'TxtHVertCep5
        '
        Me.TxtHVertCep5.Location = New System.Drawing.Point(707, 50)
        Me.TxtHVertCep5.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtHVertCep5.Name = "TxtHVertCep5"
        Me.TxtHVertCep5.Size = New System.Drawing.Size(132, 22)
        Me.TxtHVertCep5.TabIndex = 4
        '
        'Label113
        '
        Me.Label113.AutoSize = True
        Me.Label113.Location = New System.Drawing.Point(704, 29)
        Me.Label113.Name = "Label113"
        Me.Label113.Size = New System.Drawing.Size(125, 17)
        Me.Label113.TabIndex = 12
        Me.Label113.Text = "Horas Vertimiento:"
        '
        'TxtHVertimientoFl
        '
        Me.TxtHVertimientoFl.Location = New System.Drawing.Point(703, 50)
        Me.TxtHVertimientoFl.Margin = New System.Windows.Forms.Padding(4)
        Me.TxtHVertimientoFl.Name = "TxtHVertimientoFl"
        Me.TxtHVertimientoFl.Size = New System.Drawing.Size(132, 22)
        Me.TxtHVertimientoFl.TabIndex = 4
        '
        'Label119
        '
        Me.Label119.AutoSize = True
        Me.Label119.Location = New System.Drawing.Point(700, 29)
        Me.Label119.Name = "Label119"
        Me.Label119.Size = New System.Drawing.Size(125, 17)
        Me.Label119.TabIndex = 14
        Me.Label119.Text = "Horas Vertimiento:"
        '
        'FrmMineralPlant
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.ClientSize = New System.Drawing.Size(1371, 923)
        Me.Controls.Add(Me.Horometro)
        Me.Controls.Add(Me.Label46)
        Me.Controls.Add(Me.ChkTimeView)
        Me.Controls.Add(Me.CmbHoraFinal)
        Me.Controls.Add(Me.CmbHoraInicio)
        Me.Controls.Add(Me.DateTimePickerFechaReporte)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.LblArea)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.LblUsuario)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "FrmMineralPlant"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Reporte Diario de Planta"
        Me.Horometro.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DgSamplesDay, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.DgLixiviacion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.GroupBox24.ResumeLayout(False)
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        CType(Me.DgLecturaBandas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox11.PerformLayout()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        Me.GroupBox25.ResumeLayout(False)
        Me.GroupBox13.ResumeLayout(False)
        Me.GroupBox13.PerformLayout()
        CType(Me.DgMerrilCrowe, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox12.ResumeLayout(False)
        Me.GroupBox12.PerformLayout()
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        Me.GroupBox22.ResumeLayout(False)
        Me.GroupBox22.PerformLayout()
        CType(Me.DgHorometro, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox14.ResumeLayout(False)
        Me.GroupBox14.PerformLayout()
        Me.TabPage7.ResumeLayout(False)
        Me.TabPage7.PerformLayout()
        Me.GroupBox23.ResumeLayout(False)
        Me.GroupBox23.PerformLayout()
        CType(Me.DgHorometroKnelson, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox15.ResumeLayout(False)
        Me.GroupBox15.PerformLayout()
        Me.TabPage8.ResumeLayout(False)
        Me.TabPage8.PerformLayout()
        Me.GroupBox18.ResumeLayout(False)
        Me.GroupBox17.ResumeLayout(False)
        Me.GroupBox17.PerformLayout()
        CType(Me.DgFlujoE5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox16.ResumeLayout(False)
        Me.GroupBox16.PerformLayout()
        Me.TabPage9.ResumeLayout(False)
        Me.TabPage9.PerformLayout()
        Me.GroupBox20.ResumeLayout(False)
        Me.GroupBox21.ResumeLayout(False)
        Me.GroupBox21.PerformLayout()
        CType(Me.DgColasFlotacion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox19.ResumeLayout(False)
        Me.GroupBox19.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents LblArea As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents LblUsuario As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents DateTimePickerFechaReporte As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents ChkTimeView As System.Windows.Forms.CheckBox
    Friend WithEvents CmbHoraFinal As System.Windows.Forms.ComboBox
    Friend WithEvents CmbHoraInicio As System.Windows.Forms.ComboBox
    Friend WithEvents Horometro As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents DgSamplesDay As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label96 As System.Windows.Forms.Label
    Friend WithEvents TxtCommentSamples As System.Windows.Forms.TextBox
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents ChkDup As System.Windows.Forms.CheckBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Chk24hmuestras As System.Windows.Forms.CheckBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents TxtDuplicado As System.Windows.Forms.TextBox
    Friend WithEvents TxtSample As System.Windows.Forms.TextBox
    Friend WithEvents CmdSaveMuestras As System.Windows.Forms.Button
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents CmbSampleType As System.Windows.Forms.ComboBox
    Friend WithEvents CmbLocation As System.Windows.Forms.ComboBox
    Friend WithEvents ListHTo As System.Windows.Forms.ListBox
    Friend WithEvents ListHFrom As System.Windows.Forms.ListBox
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents ChKFlotaLixiSolucion As System.Windows.Forms.CheckBox
    Friend WithEvents LblTenorEspe As System.Windows.Forms.Label
    Friend WithEvents LblTonseca As System.Windows.Forms.Label
    Friend WithEvents ChkTenorFLixi As System.Windows.Forms.CheckBox
    Friend WithEvents Label93 As System.Windows.Forms.Label
    Friend WithEvents Label92 As System.Windows.Forms.Label
    Friend WithEvents LblPorSolido As System.Windows.Forms.Label
    Friend WithEvents LblPasante As System.Windows.Forms.Label
    Friend WithEvents LblDensidad As System.Windows.Forms.Label
    Friend WithEvents Label91 As System.Windows.Forms.Label
    Friend WithEvents Label89 As System.Windows.Forms.Label
    Friend WithEvents Label88 As System.Windows.Forms.Label
    Friend WithEvents DgLixiviacion As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label77 As System.Windows.Forms.Label
    Friend WithEvents Label76 As System.Windows.Forms.Label
    Friend WithEvents TxtLixiConcentrado As System.Windows.Forms.TextBox
    Friend WithEvents TxtMCubicosH As System.Windows.Forms.TextBox
    Friend WithEvents TxtGravedad As System.Windows.Forms.TextBox
    Friend WithEvents TxtPorc_Pasante As System.Windows.Forms.TextBox
    Friend WithEvents TxtDensidad As System.Windows.Forms.TextBox
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents Label70 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents CmdGuardar As System.Windows.Forms.Button
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents CmbFlujodeMasa As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents ListHoraFinal As System.Windows.Forms.ListBox
    Friend WithEvents ListHoraInicio As System.Windows.Forms.ListBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents ChkTenorBanda As System.Windows.Forms.CheckBox
    Friend WithEvents LblAlimento As System.Windows.Forms.Label
    Friend WithEvents Label86 As System.Windows.Forms.Label
    Friend WithEvents LblTenor As System.Windows.Forms.Label
    Friend WithEvents LblHumedad As System.Windows.Forms.Label
    Friend WithEvents LbltotalHumeda As System.Windows.Forms.Label
    Friend WithEvents Label85 As System.Windows.Forms.Label
    Friend WithEvents Label84 As System.Windows.Forms.Label
    Friend WithEvents Label83 As System.Windows.Forms.Label
    Friend WithEvents Label82 As System.Windows.Forms.Label
    Friend WithEvents LblTotalSeca As System.Windows.Forms.Label
    Friend WithEvents DgLecturaBandas As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Label95 As System.Windows.Forms.Label
    Friend WithEvents txtToneladas As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents TxtPercHumedad As System.Windows.Forms.TextBox
    Friend WithEvents TxtLecturaInicial As System.Windows.Forms.TextBox
    Friend WithEvents TxtLecturaFinal As System.Windows.Forms.TextBox
    Friend WithEvents ListB12Inicio As System.Windows.Forms.ListBox
    Friend WithEvents ListB12Final As System.Windows.Forms.ListBox
    Friend WithEvents GroupBox11 As System.Windows.Forms.GroupBox
    Friend WithEvents CmdReporteMineras As System.Windows.Forms.Button
    Friend WithEvents LblExportar As System.Windows.Forms.Label
    Friend WithEvents CmdExportDaily As System.Windows.Forms.Button
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents DtFechaFinal As System.Windows.Forms.DateTimePicker
    Friend WithEvents DtFechaInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents CmdOperacionEdit As System.Windows.Forms.Button
    Friend WithEvents CmdOperacion As System.Windows.Forms.Button
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents TxtTonMinera As System.Windows.Forms.TextBox
    Friend WithEvents TxtTonZandor As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents TxtStockPMFinos As System.Windows.Forms.TextBox
    Friend WithEvents TxtStockZCGruesos As System.Windows.Forms.TextBox
    Friend WithEvents TxtStockZCFinos As System.Windows.Forms.TextBox
    Friend WithEvents TxtTonHumedasZC As System.Windows.Forms.TextBox
    Friend WithEvents TxtTonhumedasPM As System.Windows.Forms.TextBox
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents Label81 As System.Windows.Forms.Label
    Friend WithEvents TxtFundicion As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents TxtOperacion As System.Windows.Forms.TextBox
    Friend WithEvents TxtTonHora As System.Windows.Forms.TextBox
    Friend WithEvents TxtHoras As System.Windows.Forms.TextBox
    Friend WithEvents TxtMtto As System.Windows.Forms.TextBox
    Friend WithEvents Txtconsumo As System.Windows.Forms.TextBox
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents DgMerrilCrowe As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox12 As System.Windows.Forms.GroupBox
    Friend WithEvents CmdSaveMC As System.Windows.Forms.Button
    Friend WithEvents Label71 As System.Windows.Forms.Label
    Friend WithEvents Label72 As System.Windows.Forms.Label
    Friend WithEvents Label73 As System.Windows.Forms.Label
    Friend WithEvents Label74 As System.Windows.Forms.Label
    Friend WithEvents TxtInicioMC As System.Windows.Forms.TextBox
    Friend WithEvents TxTFinalMC As System.Windows.Forms.TextBox
    Friend WithEvents ListMCInicio As System.Windows.Forms.ListBox
    Friend WithEvents ListMCFinal As System.Windows.Forms.ListBox
    Friend WithEvents ChkTenor As System.Windows.Forms.CheckBox
    Friend WithEvents LblExport As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents CmdSaveBanda As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents LblOnzasEspe As System.Windows.Forms.Label
    Friend WithEvents GroupBox13 As System.Windows.Forms.GroupBox
    Friend WithEvents ChkResumerril As System.Windows.Forms.CheckBox
    Friend WithEvents LblOzMerril As System.Windows.Forms.Label
    Friend WithEvents LblTenorMerril As System.Windows.Forms.Label
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents Label68 As System.Windows.Forms.Label
    Friend WithEvents LbltonMerril As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TxtMuestraBanda As System.Windows.Forms.TextBox
    Friend WithEvents LblOnzas As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents LblIdConsecutivo As System.Windows.Forms.Label
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents DgHorometro As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox14 As System.Windows.Forms.GroupBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Cmbturno As System.Windows.Forms.ComboBox
    Friend WithEvents TxtLfinalHorometro As System.Windows.Forms.TextBox
    Friend WithEvents TxtLinicialHorometro As System.Windows.Forms.TextBox
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents DgHorometroKnelson As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox15 As System.Windows.Forms.GroupBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents CmbKNelsonTurn As System.Windows.Forms.ComboBox
    Friend WithEvents TxtHKNelsonF As System.Windows.Forms.TextBox
    Friend WithEvents TxtHKNelsonI As System.Windows.Forms.TextBox
    Friend WithEvents TabPage8 As System.Windows.Forms.TabPage
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents GroupBox16 As System.Windows.Forms.GroupBox
    Friend WithEvents TxtDensidadE5 As System.Windows.Forms.TextBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents CmbTurnoE5 As System.Windows.Forms.ComboBox
    Friend WithEvents TxtFinalE5 As System.Windows.Forms.TextBox
    Friend WithEvents TxtInicioE5 As System.Windows.Forms.TextBox
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label79 As System.Windows.Forms.Label
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label99 As System.Windows.Forms.Label
    Friend WithEvents Label98 As System.Windows.Forms.Label
    Friend WithEvents Label97 As System.Windows.Forms.Label
    Friend WithEvents DgFlujoE5 As System.Windows.Forms.DataGridView
    Friend WithEvents Label94 As System.Windows.Forms.Label
    Friend WithEvents Label80 As System.Windows.Forms.Label
    Friend WithEvents Label90 As System.Windows.Forms.Label
    Friend WithEvents Label87 As System.Windows.Forms.Label
    Friend WithEvents Label102 As System.Windows.Forms.Label
    Friend WithEvents Label101 As System.Windows.Forms.Label
    Friend WithEvents Label100 As System.Windows.Forms.Label
    Friend WithEvents TxtHorasOperacione5 As System.Windows.Forms.TextBox
    Friend WithEvents Label103 As System.Windows.Forms.Label
    Friend WithEvents GroupBox17 As System.Windows.Forms.GroupBox
    Friend WithEvents LblHorasE5 As System.Windows.Forms.Label
    Friend WithEvents LblDensidadE5 As System.Windows.Forms.Label
    Friend WithEvents Label106 As System.Windows.Forms.Label
    Friend WithEvents Label107 As System.Windows.Forms.Label
    Friend WithEvents Label108 As System.Windows.Forms.Label
    Friend WithEvents LblTonsE5 As System.Windows.Forms.Label
    Friend WithEvents GroupBox18 As System.Windows.Forms.GroupBox
    Friend WithEvents DtFinalE5 As System.Windows.Forms.DateTimePicker
    Friend WithEvents DtInicioE5 As System.Windows.Forms.DateTimePicker
    Friend WithEvents CmdExportarFlowsE5 As System.Windows.Forms.Button
    Friend WithEvents TabPage9 As System.Windows.Forms.TabPage
    Friend WithEvents DgColasFlotacion As System.Windows.Forms.DataGridView
    Friend WithEvents Label104 As System.Windows.Forms.Label
    Friend WithEvents GroupBox19 As System.Windows.Forms.GroupBox
    Friend WithEvents TxtHorasFl As System.Windows.Forms.TextBox
    Friend WithEvents Label105 As System.Windows.Forms.Label
    Friend WithEvents Label109 As System.Windows.Forms.Label
    Friend WithEvents TxtDensidadFl As System.Windows.Forms.TextBox
    Friend WithEvents Label110 As System.Windows.Forms.Label
    Friend WithEvents Label111 As System.Windows.Forms.Label
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Label112 As System.Windows.Forms.Label
    Friend WithEvents CmbTurnoFl As System.Windows.Forms.ComboBox
    Friend WithEvents TxtFinalFl As System.Windows.Forms.TextBox
    Friend WithEvents TxtInicioFl As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox20 As System.Windows.Forms.GroupBox
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents DtFinalFl As System.Windows.Forms.DateTimePicker
    Friend WithEvents DtInicioFl As System.Windows.Forms.DateTimePicker
    Friend WithEvents GroupBox21 As System.Windows.Forms.GroupBox
    Friend WithEvents LbldensidadFlotacion As System.Windows.Forms.Label
    Friend WithEvents Label115 As System.Windows.Forms.Label
    Friend WithEvents Label116 As System.Windows.Forms.Label
    Friend WithEvents Label117 As System.Windows.Forms.Label
    Friend WithEvents LbltonsFlotacion As System.Windows.Forms.Label
    Friend WithEvents LblHorasFlotacion As System.Windows.Forms.Label
    Friend WithEvents GroupBox22 As System.Windows.Forms.GroupBox
    Friend WithEvents LblHorasMolienda As System.Windows.Forms.Label
    Friend WithEvents Label118 As System.Windows.Forms.Label
    Friend WithEvents GroupBox23 As System.Windows.Forms.GroupBox
    Friend WithEvents LblHorasConcentrador As System.Windows.Forms.Label
    Friend WithEvents Label114 As System.Windows.Forms.Label
    Friend WithEvents GroupBox24 As System.Windows.Forms.GroupBox
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents DtFinalB12 As System.Windows.Forms.DateTimePicker
    Friend WithEvents DtInicioB12 As System.Windows.Forms.DateTimePicker
    Friend WithEvents GroupBox25 As System.Windows.Forms.GroupBox
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents DtFinalMerril As System.Windows.Forms.DateTimePicker
    Friend WithEvents DtInicioMerril As System.Windows.Forms.DateTimePicker
    Friend WithEvents TxtHVertCep5 As System.Windows.Forms.TextBox
    Friend WithEvents Label113 As System.Windows.Forms.Label
    Friend WithEvents TxtHVertimientoFl As System.Windows.Forms.TextBox
    Friend WithEvents Label119 As System.Windows.Forms.Label
End Class
